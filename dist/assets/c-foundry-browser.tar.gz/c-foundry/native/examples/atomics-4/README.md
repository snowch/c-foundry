# Why volatile does not provide thread synchronization

Complete Linux example, ready to edit and run in the browser terminal.

## 37.4 Why volatile does not provide thread synchronization

volatile changes certain access semantics but does not make ordinary shared accesses atomic or establish thread synchronization.

The volatile variable in this fixture is accessed only by main and serves as a deliberately local example. The shared counter uses C11 atomics, not volatile. Removing atomics and merely adding volatile to the counter would create conflicting unsynchronized accesses and undefined behavior. Device-register use of volatile has additional platform-specific rules.

### main.c

```c
#define _POSIX_C_SOURCE 200809L
#include <limits.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(call)                                                            \
  do {                                                                         \
    int error = (call);                                                        \
    if (error) {                                                               \
      fprintf(stderr, "thread error %d\n", error);                             \
      exit(1);                                                                 \
    }                                                                          \
  } while (0)
atomic_uint counter;
void *increment_counter(void *unused) {
  (void)unused;
  for (unsigned i = 0; i < 1000; ++i)
    atomic_fetch_add_explicit(&counter, 1, memory_order_relaxed);
  return NULL;
}
unsigned joined_counter(void) {
  atomic_init(&counter, 0);
  pthread_t threads[4];
  for (unsigned i = 0; i < 4; ++i)
    CHECK(pthread_create(&threads[i], NULL, increment_counter, NULL));
  for (unsigned i = 0; i < 4; ++i)
    CHECK(pthread_join(threads[i], NULL));
  return atomic_load_explicit(&counter, memory_order_relaxed);
}

int main(void) {
  volatile unsigned local = 0;
  for (unsigned i = 0; i < 3; ++i)
    ++local;
  printf("local_volatile=%u atomic_total=%u\n", local, joined_counter());
  return 0;
}
```

Output:

```text
local_volatile=3 atomic_total=4000
```

The local volatile increments have no cross-thread role. The correct shared total comes from atomic fetch-add operations and worker joins.

**Watch for:** An observed correct result from a volatile shared counter does not establish a valid synchronization contract.

**Check:** Can volatile replace a mutex or atomic operation for shared increments?

1. Yes
2. No

<details><summary>Answer</summary>

No. It supplies neither the required atomic update nor the inter-thread ordering relationship.

</details>

**Try:** Edit the example in Browser Linux.  In native/examples/atomics-4/main.c, change the local volatile loop bound from 3 to 5 and repeat the terminal run. Compare local_volatile= and atomic_total=. Which quantity is local and which receives updates from more than one worker?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: atomics (included in the explanation above) — Read atomic operations and their memory-order contracts.
- Course notes: C11 concurrency (included in the explanation above) — Check thread creation, joining, mutexes, and optional implementation support.

**Optional further reading (internet required):**

- [C reference: atomics](https://en.cppreference.com/w/c/atomic.html)
- [C reference: C11 concurrency](https://en.cppreference.com/w/c/thread.html)

**Use the documentation (optional):** Does volatile make ordinary shared accesses atomic or establish inter-thread synchronization?

<details><summary>Compare your answer</summary>

No. volatile is not a substitute for atomic operations or synchronization. Use documented atomic ordering or mutex-based rules to establish the required relationships.

</details>

Native source: `native/examples/atomics-4/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=atomics-4 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

