# Interfaces, ownership contracts, and error reporting

Complete Linux example, ready to edit and run in the browser terminal.

## 9.5 Interfaces, ownership contracts, and error reporting

A usable interface explains more than parameter types. State what it borrows, what it owns, how it reports failure, and what its outputs mean after failure.

Also editable and runnable inline in the browser course. Run here, or use the native command below with your own C toolchain.

copy_name borrows a valid source string and returns a separately allocated owner through out on success. It sets a supplied output slot to NULL before a failure is possible, making the cleanup policy predictable. Distinct status values distinguish invalid arguments from allocation failure. The output slot must not already be the caller’s only owner of another allocation: overwriting that owner would leak it.

### main.c

```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum { OK, BAD_INPUT, NO_MEMORY } Status;

Status copy_name(const char *source, char **out) {
    if (!out) return BAD_INPUT;
    *out = NULL;
    if (!source) return BAD_INPUT;
    size_t bytes = strlen(source) + 1;
    char *copy = malloc(bytes);
    if (!copy) return NO_MEMORY;
    memcpy(copy, source, bytes);
    *out = copy;
    return OK;
}

int main(void) {
    char *name = NULL;
    Status result = copy_name("Ada", &name);
    if (result != OK) return 1;
    printf("%s\n", name);
    free(name);
    name = NULL;
    printf("bad input=%d\n", copy_name(NULL, &name) == BAD_INPUT);
    return 0;
}
```

Output:

```text
Ada
bad input=1
```

The caller checks the status before reading the returned string and frees it exactly once. The second call supplies an invalid source and observes BAD_INPUT with a null output. The chapter project extends this ownership contract into a multi-file record-store module.

**Watch for:** Error handling is part of the API, not an afterthought. Document output state on failure and ensure the implementation matches that promise.

**Check:** May a caller assume name is usable after any status?

1. Yes
2. Only after OK

<details><summary>Answer</summary>

Only after OK. The status determines whether the returned owner was established.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/larger-programs/5). In main.c, change the first argument of copy_name from "Ada" to "Grace". Choose Run code and compare the first line with bad input=. Which call uses the success path that must free name?

**Extend the example:** The chapter overview links the native record-store project. Its editable implementation and independent checks extend this example into a multi-file contract.

### References and help

- [C reference: functions](https://en.cppreference.com/w/c/language/functions.html) — Read declarations, parameter types, and the rules for calling functions.
- [C reference: object lifetime](https://en.cppreference.com/w/c/language/lifetime.html) — Check when an object exists and when access through a pointer becomes invalid.

Native source: `native/examples/larger-programs-5/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=larger-programs-5 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

