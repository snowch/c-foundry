# Testing truncated and corrupt input

Complete Linux example, ready to edit and run in the browser terminal.

## 25.6 Testing truncated and corrupt input

Untrusted files must be validated completely before replacing a live table. Truncated input is a normal error case, not an invitation to read partial objects.

load constructs a temporary table, validates the header, reads exact record lengths, checks decoded rows and duplicate IDs, and rejects trailing bytes. Only after reaching a clean end does it assign the output table. This fixed-size approach bounds memory use. A production format should also document checksums, limits, and evolution rules; checksums detect accidental corruption, not malicious authenticity.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { TABLE_CAP = 8 };
typedef struct {
  uint32_t id;
  char name[32];
  uint32_t score;
} Row;
typedef struct {
  Row rows[TABLE_CAP];
  size_t count;
} Table;
typedef enum { OK, DUPLICATE, FULL, INVALID, MISSING } Status;
int find_row(const Table *t, uint32_t id) {
  for (size_t i = 0; i < t->count; ++i)
    if (t->rows[i].id == id)
      return (int)i;
  return -1;
}
Status insert_row(Table *t, Row row) {
  if (row.id == 0 || !memchr(row.name, 0, sizeof row.name) || row.name[0] == 0)
    return INVALID;
  if (find_row(t, row.id) >= 0)
    return DUPLICATE;
  if (t->count == TABLE_CAP)
    return FULL;
  t->rows[t->count++] = row;
  return OK;
}
Status update_score(Table *t, uint32_t id, uint32_t score) {
  int i = find_row(t, id);
  if (i < 0)
    return MISSING;
  t->rows[i].score = score;
  return OK;
}
Status delete_row(Table *t, uint32_t id) {
  int i = find_row(t, id);
  if (i < 0)
    return MISSING;
  for (size_t j = (size_t)i + 1; j < t->count; ++j)
    t->rows[j - 1] = t->rows[j];
  --t->count;
  return OK;
}
void display(const Table *t) {
  for (size_t i = 0; i < t->count; ++i)
    printf("%u | %s | %u\n", (unsigned)t->rows[i].id, t->rows[i].name,
           (unsigned)t->rows[i].score);
}
enum { ROW_BYTES = 40, HEADER_BYTES = 8, PAGE_BYTES = 128 };
void put32(unsigned char *out, uint32_t value) {
  for (unsigned i = 0; i < 4; ++i)
    out[i] = (unsigned char)(value >> (8 * i));
}
uint32_t get32(const unsigned char *in) {
  uint32_t value = 0;
  for (unsigned i = 0; i < 4; ++i)
    value |= (uint32_t)in[i] << (8 * i);
  return value;
}
bool encode_row(unsigned char *out, const Row *row) {
  if (!row->id || !memchr(row->name, 0, 32) || !row->name[0])
    return false;
  memset(out, 0, ROW_BYTES);
  put32(out, row->id);
  memcpy(out + 4, row->name, strlen(row->name));
  put32(out + 36, row->score);
  return true;
}
bool decode_row(const unsigned char *in, size_t n, Row *out) {
  if (n != ROW_BYTES || get32(in) == 0 || !memchr(in + 4, 0, 32) || in[4] == 0)
    return false;
  Row row = {0};
  row.id = get32(in);
  memcpy(row.name, in + 4, 32);
  row.score = get32(in + 36);
  *out = row;
  return true;
}
bool save(FILE *f, const Table *table) {
  unsigned char header[HEADER_BYTES] = {0x54, 0x44,      0x42, 0x31,
                                        1,    ROW_BYTES, 0,    0};
  if (table->count > TABLE_CAP)
    return false;
  header[6] = (unsigned char)table->count;
  if (fwrite(header, 1, sizeof header, f) != sizeof header)
    return false;
  for (size_t i = 0; i < table->count; ++i) {
    unsigned char bytes[ROW_BYTES];
    if (!encode_row(bytes, &table->rows[i]) ||
        fwrite(bytes, 1, sizeof bytes, f) != sizeof bytes)
      return false;
  }
  return fflush(f) == 0;
}
bool load(FILE *f, Table *out) {
  unsigned char header[HEADER_BYTES];
  if (fread(header, 1, sizeof header, f) != sizeof header)
    return false;
  if (memcmp(header, (const unsigned char[]){0x54, 0x44, 0x42, 0x31}, 4) || header[4] != 1 || header[5] != ROW_BYTES ||
      header[6] > TABLE_CAP || header[7] != 0)
    return false;
  Table table = {.count = 0};
  for (unsigned i = 0; i < header[6]; ++i) {
    unsigned char bytes[ROW_BYTES];
    Row row;
    if (fread(bytes, 1, sizeof bytes, f) != sizeof bytes ||
        !decode_row(bytes, sizeof bytes, &row) || insert_row(&table, row) != OK)
      return false;
  }
  if (fgetc(f) != EOF || ferror(f))
    return false;
  *out = table;
  return true;
}

int main(void) {
  FILE *f = tmpfile();
  if (!f)
    return 1;
  unsigned char bad[] = {0x54, 0x44, 0x42, 0x31, 1, 40, 1, 0, 7};
  if (fwrite(bad, 1, sizeof bad, f) != sizeof bad ||
      fseek(f, 0, SEEK_SET) != 0) {
    fclose(f);
    return 1;
  }
  Table live = {.count = 0};
  insert_row(&live, (Row){9, "Keep", 1});
  bool loaded = load(f, &live);
  printf("rejected=%d retained=%s count=%zu\n", !loaded, live.rows[0].name,
         live.count);
  if (fclose(f) != 0)
    return 1;
  return 0;
}
```

Output:

```text
rejected=1 retained=Keep count=1
```

The header declares one forty-byte row but provides only one byte. Loading fails and the previously live Keep row remains unchanged.

### Reject a partial file before replacing the live table

What happens to the existing Keep row when the load fails?

Before loading, the live table contains one row: ID 9, name Keep, score 1. The supplied file declares one forty-byte row but contains only one payload byte, 7. The loader reads into temporary candidate storage, detects the truncated row, and rejects the load. It never assigns the candidate to the live table, which still contains the same Keep row with count 1.

This illustrates failure-atomic replacement in memory. It does not establish crash durability or validate every possible malformed file.

**Watch for:** Assigning decoded rows directly into the live table before validating the entire file makes rejection destructive.

**Check:** When may load replace the caller’s live table?

1. Immediately after reading the magic bytes
2. Only after complete validation succeeds

<details><summary>Answer</summary>

Only after complete validation succeeds. Later records or trailing input may still invalidate the file.

</details>

**Try:** Edit the example in Browser Linux.  In native/examples/persistence-6/main.c, change the final byte 7 in bad to 9 while leaving the file short. Repeat the terminal command. What do rejected=, retained=, and count= show about the existing table after a failed import?

**Extend the example:** An independent folder of malformed files can cover truncation at every byte, duplicate IDs, a missing name terminator and trailing bytes. For each one, start with a known live row and check that failed import preserves it.

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: database file format (included in the explanation above) — Compare explicit headers, page layouts, and encoding rules with the teaching format.
- [Read stdio(3)](../../manuals/stdio.3.txt) (included) — stdio - standard input/output library functions

**Optional further reading (internet required):**

- [SQLite documentation: database file format](https://www.sqlite.org/fileformat.html)
- [C reference: input/output](https://en.cppreference.com/w/c/io.html)

Native source: `native/examples/persistence-6/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=persistence-6 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

