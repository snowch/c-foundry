# Auditing assumptions about types and memory

Complete Linux example, ready to edit and run in the browser terminal.

## 34.1 Auditing assumptions about types and memory

An assumption audit checks where input sizes, arithmetic ranges, alignment, and lifetimes cross API boundaries.

Also editable and runnable inline in the browser course. This probe runs with the inline browser’s fixed C17 toolchain. Use Browser Linux for GCC/Clang comparisons and supported language modes. Optional external sanitizer tooling is described separately.

For an array allocation, validate count≤SIZE_MAX/element_size before multiplication. Also define a zero-element policy and who owns the result. The fixture rejects an impossible int-array size without attempting memory exhaustion. Similar checks belong in page offsets, slot lengths, result buffers, and log record counts. Include sizeof(long), size_t and printf formats, char signedness, execution character set, eight-bit-byte requirements, optional exact-width types, and alignment in the audit. Record each as guaranteed by C17, required of supported targets, validated at an input boundary, or delegated to a host adapter. A compiler accepting the source does not discharge the remaining assumptions.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
  size_t count = SIZE_MAX;
  bool rejected = count > SIZE_MAX / sizeof(int);
  printf("oversize_rejected=%d\n", rejected);
  return 0;
}
```

Output:

```text
oversize_rejected=1
```

On the supported targets sizeof(int)>1, so the requested count cannot fit a byte size. The operating system is not asked to perform a huge allocation.

**Watch for:** A NULL check after an already overflowing multiplication does not repair the requested size.

**Check:** When must multiplication overflow be checked?

1. Before multiplying
2. Only after malloc fails

<details><summary>Answer</summary>

Before multiplying. An overflowed size may request a small allocation and later cause an out-of-bounds write.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/hardening-tinydb/1). In main.c, change count from SIZE_MAX to 8. Run code and compare oversize_rejected=. Which part of the division-based bound lets the smaller request pass without first multiplying?

### References and help

- [C reference: numeric limits](https://en.cppreference.com/w/c/types/limits.html) — Find the macros that describe the selected implementation’s ranges.
- [C reference: behavior categories](https://en.cppreference.com/w/c/language/behavior.html) — Distinguish undefined, unspecified, and implementation-defined behavior.

Native source: `native/examples/hardening-tinydb-1/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=hardening-tinydb-1 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

