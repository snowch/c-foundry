# Chapter 14: Recursion and divide and conquer

Part 3: Learn to reason about algorithms. Teaching baseline: C17.

Make recursive subproblems smaller, track each call’s state, and compare explicit and implicit stacks.

## Outcomes

- Identify a base case and a decreasing measure.
- Account for recursive auxiliary space.
- Traverse a directory-like tree without assuming parent data disappears.

## 14.1 Base cases and recursive progress

A recursive function needs both a terminating base case and progress toward it on every recursive path.

Factorial on the small domain 0..10 uses 0!=1 and n!=n·(n−1)!. The argument decreases until it is less than two. The domain restriction matters: machine integers are finite, so this is not an implementation for arbitrarily large mathematical factorials.

### Recursive calls keep unfinished work

Each call waits for the smaller subproblem to return.

factorial(3) needs 3 times factorial(2). factorial(2) needs 2 times factorial(1). The base case factorial(1) returns 1. Unwinding returns 2 to the waiting outer call, which returns 6. Each active call has its own local state.

This illustrates the course’s small checked factorial domain, not an arbitrary-precision calculation.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

unsigned factorial(unsigned n) { return n < 2 ? 1 : n * factorial(n - 1); }
unsigned factorial_loop(unsigned n) {
  unsigned result = 1;
  for (unsigned i = 2; i <= n; ++i)
    result *= i;
  return result;
}

int main(void) {
  printf("zero=%u five=%u\n", factorial(0), factorial(5));
  return 0;
}
```

Output:

```text
zero=1 five=120
```

Zero returns at the base case. Five multiplies 5·4·3·2·1 while calls return.

**Watch for:** A base case that cannot be reached from a valid input does not guarantee termination.

**Check:** In factorial, what decreases on each recursive call made when n is at least 2?

1. The unsigned argument for n≥2
2. The size of the result

<details><summary>Answer</summary>

The unsigned argument for n≥2. Each recursive call receives n−1 only when n is at least two.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/recursion/1). In main.c, replace factorial(5) with factorial(4) and change the five= label to four=. Run code. How does the new result follow from the starter’s result, and which base-case value remains?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: recursion (included in the explanation above) — Identify base cases and progress toward them.

**Optional further reading (internet required):**

- [NIST DADS: recursion](https://xlinux.nist.gov/dads/HTML/recursion.html)

**Use the documentation (optional):** Which two parts of a recursive algorithm prevent the same subproblem from recurring forever?

<details><summary>Compare your answer</summary>

A terminating base case and recursive steps that make progress toward it. A base case alone is insufficient if reachable steps never approach it.

</details>

Native source: `native/examples/recursion-1.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=recursion-1 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 14.2 Drawing the call stack

Each recursive call has its own parameters and local state. Trace entry and return to distinguish the active call from its caller.

The countdown prints before and after its recursive call. Its local n remains unchanged while the child runs. At the base case, the function returns without making another call. Stack depth grows linearly with the initial n; a huge input can exhaust implementation resources even when the recurrence terminates mathematically.

### Recursive calls keep unfinished work

Each call waits for the smaller subproblem to return.

factorial(3) needs 3 times factorial(2). factorial(2) needs 2 times factorial(1). The base case factorial(1) returns 1. Unwinding returns 2 to the waiting outer call, which returns 6. Each active call has its own local state.

This illustrates the course’s small checked factorial domain, not an arbitrary-precision calculation.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void visit(unsigned n) {
  printf("enter %u\n", n);
  if (n)
    visit(n - 1);
  printf("leave %u\n", n);
}

int main(void) {
  visit(2);
  return 0;
}
```

Output:

```text
enter 2
enter 1
enter 0
leave 0
leave 1
leave 2
```

Returns unwind in the reverse order of calls, because each caller resumes after its child completes.

**Watch for:** The trace describes logical call nesting, not a portable memory-address layout of the native stack.

**Check:** In the original visit(2) trace, which call returns first?

1. The initial call with n=2
2. The base-case call with n=0

<details><summary>Answer</summary>

The base-case call with n=0. The caller waits for the child’s result.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/recursion/2). In main.c, change visit(2) to visit(3). Run code and compare the enter and leave lines. At which line are the most calls active? Draw one box for each call already entered and still waiting to leave.

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: recursion (included in the explanation above) — Identify base cases and progress toward them.

**Optional further reading (internet required):**

- [NIST DADS: recursion](https://xlinux.nist.gov/dads/HTML/recursion.html)

Native source: `native/examples/recursion-2.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=recursion-2 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 14.3 Recursive versus iterative implementations

An iterative formulation can remove recursive call overhead and stack growth when the problem permits a compact accumulator.

Both factorial implementations compute the same small-domain result. The loop keeps one accumulator and counter, using O(1) auxiliary space; the direct recursive version has O(n) active call depth. Tail-call optimization is not a C language guarantee, so do not use it as a correctness or space-safety assumption.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

unsigned factorial(unsigned n) { return n < 2 ? 1 : n * factorial(n - 1); }
unsigned factorial_loop(unsigned n) {
  unsigned result = 1;
  for (unsigned i = 2; i <= n; ++i)
    result *= i;
  return result;
}

int main(void) {
  printf("recursive=%u iterative=%u\n", factorial(6), factorial_loop(6));
  return 0;
}
```

Output:

```text
recursive=720 iterative=720
```

Equality of results is checked for one fixture; test the entire documented small domain before replacing the implementation.

**Watch for:** Changing control structure does not remove overflow from an unchecked arithmetic formula.

**Check:** Does C require tail-call elimination?

1. No
2. Yes

<details><summary>Answer</summary>

No. An implementation may preserve a call frame for each recursive call.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/recursion/3). In main.c, change 6 to 8 in both calls. Run code and compare recursive= and iterative=. What evidence shows the answers agree for 8, and what would you need to claim they agree over the full supported domain?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: recursion (included in the explanation above) — Identify base cases and progress toward them.

**Optional further reading (internet required):**

- [NIST DADS: recursion](https://xlinux.nist.gov/dads/HTML/recursion.html)

Native source: `native/examples/recursion-3.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=recursion-3 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 14.4 Recursion trees and simple recurrences

A recursion tree exposes how many subproblems exist at each depth and how much nonrecursive work each node performs.

A balanced split into two half-sized problems with constant leaf cost and linear combine cost satisfies T(n)=2T(n/2)+Θ(n). Every level contributes Θ(n) work, and the tree has Θ(log n) levels. Count leaves separately from the total number of nodes; for the example’s power-of-two input, there are n leaves and 2n−1 nodes.

### Count calls at each split depth

For eight elements, four depths contain fifteen calls and eight leaves.

Start with one call of size eight at depth zero. It creates two calls of size four at depth one, then four calls of size two at depth two, then eight calls of size one at depth three. Size-one calls are leaves. Adding the call counts gives fifteen; the final depth has eight leaves. The table counts calls, not elapsed time or merge operations.

This is the power-of-two split fixture. A merge-sort combine step adds work not counted by this program.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void count_tree(unsigned n, unsigned *nodes, unsigned *leaves) {
  ++*nodes;
  if (n < 2) {
    ++*leaves;
    return;
  }
  count_tree(n / 2, nodes, leaves);
  count_tree(n - n / 2, nodes, leaves);
}

int main(void) {
  unsigned nodes = 0, leaves = 0;
  count_tree(8, &nodes, &leaves);
  printf("nodes=%u leaves=%u\n", nodes, leaves);
  return 0;
}
```

Output:

```text
nodes=15 leaves=8
```

This program counts the split tree only. A merge-sort combine step adds linear work at each internal node, producing the extra logarithmic factor.

**Watch for:** Two recursive calls do not by themselves imply exponential work; their argument sizes matter.

**Check:** What detail distinguishes merge sort from two calls on n−1?

1. Both use two function calls
2. The subproblem sizes shrink by about half

<details><summary>Answer</summary>

The subproblem sizes shrink by about half. A recurrence must describe sizes and nonrecursive work, not just call count.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/recursion/4). In main.c, change count_tree(8, &nodes, &leaves) to count_tree(7, &nodes, &leaves). Run code and compare nodes= and leaves=. Draw the uneven split and explain why a single work count leaves the asymptotic argument open.

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: recursion (included in the explanation above) — Identify base cases and progress toward them.
- Course notes: Big O (included in the explanation above) — Read an asymptotic bound as a growth claim, not an exact operation count.

**Optional further reading (internet required):**

- [NIST DADS: recursion](https://xlinux.nist.gov/dads/HTML/recursion.html)
- [NIST DADS: Big O](https://xlinux.nist.gov/dads/HTML/bigOnotation.html)

Native source: `native/examples/recursion-4.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=recursion-4 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 14.5 Recursive directory-like tree traversal

A tree traversal visits each node and recursively processes its children. Directory-like structure can be modeled without requiring filesystem access.

Nodes borrow immutable names and child arrays. Preorder visits the parent before its descendants. For a tree with V nodes, traversal takes Θ(V) visits and O(h) active stack depth, where h is its height. A general graph needs a visited policy to avoid revisiting nodes or following cycles forever.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Node {
  const char *name;
  const struct Node *children;
  size_t count;
} Node;
void walk(const Node *node, unsigned depth) {
  for (unsigned i = 0; i < depth; ++i)
    printf("  ");
  puts(node->name);
  for (size_t i = 0; i < node->count; ++i)
    walk(&node->children[i], depth + 1);
}

int main(void) {
  Node files[] = {{"main.c", NULL, 0}, {"db.c", NULL, 0}};
  Node root = {"src", files, 2};
  walk(&root, 0);
  return 0;
}
```

Output:

```text
src
  main.c
  db.c
```

The root prints first and each leaf prints one indentation level deeper. No host directory is opened.

**Watch for:** Deep or cyclic external structures need depth limits and validation; a trusted small tree does not demonstrate those protections.

**Check:** What controls the active recursion depth?

1. The tree’s height
2. Only the number of siblings

<details><summary>Answer</summary>

The tree’s height. Calls remain active along the current root-to-node path.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/recursion/5). In main.c, append {"util.c", NULL, 0} to files and change root’s child count from 2 to 3. Run code and inspect the indentation of all three files. Which value tracks the depth of each recursive call?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: recursion (included in the explanation above) — Identify base cases and progress toward them.

**Optional further reading (internet required):**

- [NIST DADS: recursion](https://xlinux.nist.gov/dads/HTML/recursion.html)

Native source: `native/examples/recursion-5.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=recursion-5 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## Build it yourself

Traverse a tree and account for the recursive call stack.

1. Add a nested directory and then implement the traversal with an explicit bounded stack.
2. Compare recursive and explicit-stack traversal on an empty tree, a leaf, and a nested directory; define a depth limit.

### Check your work

- Check the same visit order and count the greatest number of unfinished calls or stack entries.

Baseline command (checks original output, not every extension):

```sh
make example EXAMPLE=recursion-5
```

Chapter workspace command: `make chapter CHAPTER=recursion`.

Generated from dist/part3.js by tools/sync_readings.cjs. Full reading: https://snowch.github.io/c-foundry/#/chapter/recursion
