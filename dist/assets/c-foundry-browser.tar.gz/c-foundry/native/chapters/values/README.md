# Chapter 2: Values, types, and expressions

Part 1: Learn the language. Teaching baseline: C17.

Learn what your data can represent, how expressions are evaluated, and when conversions change the result. These rules are the foundation of reliable arithmetic in every later project.

## Outcomes

- Choose and initialize basic C17 types with matching printf formats.
- Predict integer division, precedence, and casts before executing.
- Distinguish defined unsigned wrap from undefined signed overflow.

## 2.1 Integers, floating-point numbers, characters, and Boolean values

A type determines the values an object can represent and the operations that make sense for it. Choose a type from the meaning and range of the data, rather than assuming every number should be an int.

`int` represents whole numbers, while `double` represents floating-point approximations. `char` is an integer type used for character-sized storage; a character literal such as `'A'` uses single quotes. In C17, include `<stdbool.h>` to use `bool`, `true`, and `false`. The language also provides short, long, long long, and unsigned integer variants, and float and long double for other floating-point ranges or precision. This introduction uses double for fractional calculations. A float argument to printf is promoted to double; scanf follows different format rules, so do not transfer printf formats to input functions without checking their contracts.

**One compiler’s sizes are not a C guarantee**

C guarantees minimum ranges, not one size for every type. For example, `int` must represent at least −32767 through 32767; it need not be 32 bits. A C byte is the size of `char` and has at least 8 bits. `<stdint.h>` provides exact-width names such as `uint32_t` when that width is supported; `uint_least32_t` guarantees at least 32 value bits. [Chapter 10 shows fixed-width values and their print formats](https://snowch.github.io/c-foundry/#/chapter/files-bytes/2); [Part 7 applies them to portable files](https://snowch.github.io/c-foundry/#/chapter/portable-c/2).

### main.c

```c
#include <stdio.h>
#include <stdbool.h>

int main(void) {
    int count = 7;
    double distance = 2.5;
    char letter = 'A';
    bool ready = true;
    printf("%d %.1f %c %d\n", count, distance, letter, ready);
    double tenth = 0.1;
    printf("rounded: %.1f\n", tenth);
    printf("more digits: %.17f\n", tenth);
    return 0;
}
```

Output:

```text
7 2.5 A 1
rounded: 0.1
more digits: 0.10000000000000001
```

The first line uses %d for int, %.1f for double with one fractional digit, and %c for a character value. The bool argument is promoted to int and prints as 1. The last two lines print the same stored tenth with different formats. On this browser target, double uses binary fractions: 2.5 is exact, but 0.1 lies between representable values. The extra digits expose its approximation. Formatting changes the displayed digits, not the stored value. [Part 7 explores rounding and choosing tolerances for comparisons](https://snowch.github.io/c-foundry/#/chapter/c-guarantees/8).

**Watch for:** The format string does not convert an incorrectly typed argument into the expected type. For example, passing a double to %d is not a safe shortcut.

**Check:** Which format is appropriate for printing a double with one decimal place?

1. %d
2. %.1f
3. %c

<details><summary>Answer</summary>

%.1f. The f conversion expects a double; .1 requests one digit after the decimal point.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/values/1). In main.c after the first run, change count from 7 to 9, distance from 2.5 to 4.0, letter from 'A' to 'B', and ready from true to false. Predict the four fields and choose Run code. In Console, which field shows a Boolean as an integer? Then change tenth from 0.1 to 0.5 and run again. Compare rounded: and more digits:. Can this binary floating-point type represent one half exactly?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- [Read printf(3)](../../manuals/printf.3.txt) (included) — Read conversion specifiers, required argument types, and the return value.
- Course notes: arithmetic types (included in the explanation above) — Compare integer ranges, signedness, and floating-point types.
- Course notes: numeric limits (included in the explanation above) — Find the macros that describe the selected implementation’s ranges.

**Optional further reading (internet required):**

- [C reference: arithmetic types](https://en.cppreference.com/w/c/language/arithmetic_types.html)
- [C reference: numeric limits](https://en.cppreference.com/w/c/types/limits.html)

**Use the documentation (optional):** Which argument type does printf expect for %d, and which type does %f receive?

<details><summary>Compare your answer</summary>

%d receives int. printf’s %f receives double; a float argument is promoted to double. Input functions such as scanf have different contracts.

</details>

Native source: `native/examples/values-1.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=values-1 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 2.2 Variables, initialization, and constants

A variable is a named object whose stored value may change. Initialization gives it a starting value at its declaration. A later assignment replaces the value it holds.

Declare and initialize small local variables near their first use. An uninitialized automatic int has an indeterminate value; do not read it before assigning a valid value. `const` expresses that an object should not be modified through that declaration. It helps document intent and lets the compiler reject accidental writes. In C, a const-qualified object is not automatically an integer constant expression in every context; that distinction matters later for array bounds and declarations.

### main.c

```c
#include <stdio.h>

int main(void) {
    const int unit_price = 7;
    int quantity = 3;
    int total = unit_price * quantity;
    quantity = 4;
    printf("%d %d\n", total, quantity);
    return 0;
}
```

Output:

```text
21 4
```

total is calculated when its initializer runs. It stores 21; it is not a formula that automatically tracks quantity. Assigning 4 to quantity changes that object only. The later printf therefore prints the old calculated total and the new quantity. To update total, evaluate the multiplication and assign again.

### Assignment stores a value at that moment

Does total change when quantity changes later?

With unit_price equal to 7 and quantity equal to 3, the initialization stores 21 in total. The later assignment stores 4 in quantity. It does not repeat the multiplication: total still contains 21. The program therefore prints total 21 followed by quantity 4.

These are values in the supplied example, not a live view of your edits. Reassign total to calculate a new product.

**Watch for:** Use = for assignment. It stores a value and is different from ==, which compares values. A statement such as total = quantity changes total, even if the names suggest a calculation.

**Check:** If total was initialized using quantity = 3, does assigning quantity = 4 alone recompute total?

1. Yes
2. No

<details><summary>Answer</summary>

No. An initializer is evaluated once at that point in execution. C does not maintain spreadsheet-like dependencies.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/values/2). In main.c, add total = unit_price * quantity; just after quantity = 4;. Choose Run code. The first Console field changes from 21 to 28 and the second remains 4. When does C evaluate the multiplication?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: initialization (included in the explanation above) — Find the rules for explicit initializers and omitted aggregate members.
- Course notes: arithmetic types (included in the explanation above) — Compare integer ranges, signedness, and floating-point types.

**Optional further reading (internet required):**

- [C reference: initialization](https://en.cppreference.com/w/c/language/initialization.html)
- [C reference: arithmetic types](https://en.cppreference.com/w/c/language/arithmetic_types.html)

Native source: `native/examples/values-2.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=values-2 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 2.3 Operators and precedence

An expression combines values and operators to compute a result. Parentheses make grouping explicit; they are often clearer than expecting a reader to remember every precedence rule.

Multiplication, division, and remainder bind more tightly than addition and subtraction. When both operands of division are integers, the result is an integer truncated toward zero: 7 / 2 is 3. The remainder operator % works on integers; for these positive operands, 7 % 2 is 1. Division by zero is invalid. Evaluation order is a separate issue from precedence: grouping does not generally tell you the order in which unrelated function calls or side effects are evaluated.

### main.c

```c
#include <stdio.h>

int main(void) {
    printf("%d %d\n", 7 / 2, 7 % 2);
    printf("%d %d\n", 2 + 3 * 4, (2 + 3) * 4);
    return 0;
}
```

Output:

```text
3 1
14 20
```

The first line reports three complete groups of two, with one left over: 7 = 3 × 2 + 1. On the second line, multiplication happens within the higher-precedence subexpression, yielding 14. Parentheses change the grouping to add first and yield 20. To obtain a fractional quotient, make a division operand floating point before division, as the next topic shows.

**Watch for:** Avoid expressions that modify and read the same object in unsequenced ways. Write separate, simple statements instead of clever chains of increments and assignments.

**Check:** What is the value of (2 + 3) * 4?

1. 14
2. 20
3. 24

<details><summary>Answer</summary>

20. Parentheses group the addition, producing 5 before the multiplication produces 20.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/values/3). In main.c, replace 7 / 2 and 7 % 2 in the first printf with 9 / 4 and 9 % 4. Choose Run code and read the first Console row. How do its quotient and remainder reconstruct 9?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: operator precedence (included in the explanation above) — Use the precedence table, then check the operator’s own semantics.

**Optional further reading (internet required):**

- [C reference: operator precedence](https://en.cppreference.com/w/c/language/operator_precedence.html)

Native source: `native/examples/values-3.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=values-3 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 2.4 Conversions, casts, and integer promotions

C converts values when types differ, but the point at which a conversion happens matters. Converting a completed integer result cannot recover a fraction that integer division already discarded.

In a mixed expression involving double and an ordinary integer, the integer can be converted to double before arithmetic. A cast explicitly requests a conversion. Thus `(double)7 / 2` performs floating-point division, whereas `(double)(7 / 2)` first computes the integer quotient. Smaller integer types commonly undergo integer promotion in expressions. Signed/unsigned combinations have additional conversion rules, so avoid mixing them casually when testing ranges. Part 7’s numeric-boundary lessons revisit promotions and signed/unsigned comparisons with checked interfaces after functions and pointers have been introduced.

### main.c

```c
#include <stdio.h>

int main(void) {
    double fractional = (double)7 / 2;
    double truncated = 7 / 2;
    printf("%.1f %.1f\n", fractional, truncated);
    return 0;
}
```

Output:

```text
3.5 3.0
```

fractional receives 3.5 because conversion happens before division. truncated receives the double value 3.0 because the integer expression has already produced 3. Changing the receiving variable’s type does not change how the right-hand expression was evaluated. Cast at a specific, justified boundary rather than scattering casts to suppress warnings.

**Watch for:** A cast is not proof that a value fits. Converting a floating-point value outside the representable range of an integer type is not a valid way to clamp it. Validate the range before converting.

**Check:** Which expression preserves the fractional part of seven divided by two?

1. (double)(7 / 2)
2. (double)7 / 2

<details><summary>Answer</summary>

(double)7 / 2. The second expression converts an operand before division; the first converts an already truncated quotient.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/values/4). In main.c, replace (double)7 / 2 with 7.0 / 2 in fractional. Choose Run code and compare both Console fields with the starter. Which operand now makes the first division floating-point?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: conversions (included in the explanation above) — Check integer promotions, usual arithmetic conversions, and narrowing.

**Optional further reading (internet required):**

- [C reference: conversions](https://en.cppreference.com/w/c/language/conversion.html)

Native source: `native/examples/values-4.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=values-4 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 2.5 Integer ranges, signed overflow, and unsigned arithmetic

C’s numeric types have finite ranges. Correct code distinguishes unsigned arithmetic, which wraps modulo its type’s range, from signed overflow, whose behavior is undefined.

Use `<limits.h>` for bounds such as INT_MAX, INT_MIN, and UINT_MAX. Use `sizeof(int)` to find its storage size in C bytes, and `CHAR_BIT` for the number of bits in a byte; storage bits may include padding. Neither result replaces the value bounds in limits.h. A signed addition must be checked before it overflows, not afterward. Unsigned wrap is defined, but it can still be a bug in sizes or indexes. Floating-point types have separate limits and precision characteristics described by `<float.h>`. Part 7’s What C guarantees chapter extends this introduction with checked arithmetic, exceptional division and negation, rounding, NaN/infinity, and underflow.

### Unsigned wrap and signed overflow are different

Only the unsigned result is defined to wrap modulo its type’s range.

Adding unsigned 1 to UINT_MAX yields unsigned zero by modular arithmetic. Evaluating signed INT_MAX plus signed 1 exceeds the signed int range and has undefined behavior. Do not evaluate that signed expression to test whether it overflowed; check beforehand.

No particular int width is assumed.

### main.c

```c
#include <stdio.h>
#include <limits.h>

int main(void) {
    unsigned int value = 0;
    value -= 1;
    printf("%d\n", value == UINT_MAX);
    return 0;
}
```

Output:

```text
1
```

Subtracting one from unsigned zero wraps to UINT_MAX. The comparison is true, so printf prints 1. This is a defined unsigned operation. Replacing value with a signed int and deliberately overflowing its range would not be a comparable experiment: a particular output would provide no guarantee about that invalid program.

**Watch for:** Do not use an observed wraparound result from signed overflow as evidence of a language rule. Optimizers can assume undefined signed overflow does not occur. Later portability chapters revisit these guarantees in depth.

**Check:** Is overflowing a signed int guaranteed to wrap?

1. Yes, on every C implementation
2. No; signed overflow has undefined behavior

<details><summary>Answer</summary>

No; signed overflow has undefined behavior. Unsigned arithmetic has defined modular behavior. Ordinary signed overflow does not.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/values/5). In main.c, change value -= 1; to value -= 2;. Choose Run code and compare the printed test against UINT_MAX with the starter. Then change the test to value == UINT_MAX - 1 and run again. Which value does defined unsigned subtraction produce?

**Extend the example:** Before return 0;, add printf("int bytes=%zu bits per byte=%d max=%d\n", sizeof(int), CHAR_BIT, INT_MAX); and run again. In Console, identify the storage size, bits per byte, and largest int value on this target. These are measurements of this implementation, not sizes guaranteed for every C platform.

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: numeric limits (included in the explanation above) — Find the macros that describe the selected implementation’s ranges.
- Course notes: behavior categories (included in the explanation above) — Distinguish undefined, unspecified, and implementation-defined behavior.

**Optional further reading (internet required):**

- [C reference: numeric limits](https://en.cppreference.com/w/c/types/limits.html)
- [C reference: behavior categories](https://en.cppreference.com/w/c/language/behavior.html)

Native source: `native/examples/values-5.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=values-5 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## Chapter practice

Edit `native/exercises/numbers.c`, then run:

```sh
make exercise EXERCISE=numbers
```

Chapter workspace command: `make chapter CHAPTER=values`.

Generated from dist/part1.js by tools/sync_readings.cjs. Full reading: https://snowch.github.io/c-foundry/#/chapter/values
