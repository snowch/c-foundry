# Chapter 1: Your first C program

Part 1: Learn the language. Teaching baseline: C17.

Write, run, and diagnose a complete C program. You will learn which parts of the source are declarations, statements, and output, and what the browser runner does with them.

## Outcomes

- Trace source through compilation, linking, and execution.
- Write a valid main and format a short output message.
- Use diagnostics to fix a missing-semicolon error and export a file.
- Find a function reference, identify its contract, and verify a documented result.

## 1.1 Source code, compilation, linking, and execution

Your main.c file is text. Before it can run, tools prepare it, translate it, and connect it to library code.

<strong>Preprocessing</strong> handles lines such as `#include <stdio.h>`, which brings in descriptions of available functions. The <strong>compiler</strong> checks your C and translates it into an object file, one piece of the program. The <strong>linker</strong> connects that piece to library code such as `printf`. Together, these steps <strong>build</strong> the program. Here the result is <strong>WebAssembly</strong>: a binary program format the browser can run. A local build can instead produce an executable for your computer. <strong>Run code</strong> builds and runs the program for you.

### Source becomes a runnable program

Preprocessing, compilation, linking, and execution have different jobs.

Start with main.c. Preprocessing expands includes and macros. Compilation translates the resulting C into object code. The linker resolves references between objects and libraries and produces a program. A native operating system or a Wasm runtime executes the result. A successful translation is separate from a successful run.

The target determines whether the final program is native code or a WebAssembly module.

### main.c

```c
#include <stdio.h>

int main(void) {
    printf("Hello, C!\n");
    return 0;
}
```

Output:

```text
Hello, C!
```

The header declares printf so the compiler can check its use. The call asks the runtime to write a line. The final return ends main successfully. The browser lab performs the compile, link, and run stages when you choose Run code; you do not need to install a compiler for Part 1.

**Watch for:** A compiler error prevents the new program from running. A runtime error happens after compilation and linking have succeeded. Treat these as different points in the process.

**Check:** Which stage connects your program to the library code for printf?

1. Editing
2. Linking
3. Running

<details><summary>Answer</summary>

Linking. The linker connects the translated program with the library code it needs.

</details>

**Try:** Change the greeting, run the program, and check that the console reflects the new text.

### References and help

- [GCC manual: compilation stages](https://gcc.gnu.org/onlinedocs/gcc/Overall-Options.html) — Compare preprocessing, compilation, assembly, and linking; inspect -E, -S, and -c.
- [WebAssembly concepts](https://developer.mozilla.org/en-US/docs/WebAssembly/Guides/Concepts) — Distinguish source code, a Wasm module, and the host/runtime that supplies its environment.

Run from the repository root:

```sh
make example EXAMPLE=first-program-1
```

## 1.2 main, statements, comments, and return values

Execution begins in main for the small hosted C programs in this course. Read the function body from its opening brace to its closing brace: statements normally execute in order.

`int main(void)` says that main returns an integer status and takes no arguments. The braces delimit its body. An expression statement such as a function call ends in a semicolon. A `//` comment continues to the end of its line; a `/* ... */` comment can span several lines. Comments help a reader understand intent but do not execute. Function definitions and return values get a fuller treatment in Chapter 4.

### main.c

```c
#include <stdio.h>

int main(void) {
    // Print two messages, in order.
    printf("First\n");
    printf("Second\n");
    return 0;
}
```

Output:

```text
First
Second
```

The first printf completes before the second call is reached. Each string contains a newline, so the two calls produce two lines. Returning 0 tells the environment that the program completed successfully. It is a status, not a request to print the number zero.

**Watch for:** Braces group statements; semicolons terminate many statements. A missing semicolon can cause an error on the following line, where the compiler finally notices the problem.

**Check:** Does return 0 print a zero in the console?

1. Yes
2. No

<details><summary>Answer</summary>

No. Returning a status and writing output are separate operations.

</details>

**Try:** Swap the two printf statements. Predict the new order before running.

### References and help

- [C reference: main](https://en.cppreference.com/w/c/language/main_function.html) — Check the supported forms of main and what returning a status means.
- [C reference: functions](https://en.cppreference.com/w/c/language/functions.html) — Read declarations, parameter types, and the rules for calling functions.

Run from the repository root:

```sh
make example EXAMPLE=first-program-2
```

## 1.3 Printing with printf

printf writes formatted text. The first argument is a format string: ordinary characters are printed, while conversion specifications describe how to print later arguments.

A string literal uses double quotes. Within it, `\n` represents a newline, `\t` a tab, `\\` a backslash, and `\"` a double quote. The specification `%d` expects an int; `%%` prints a literal percent sign and consumes no argument. The order and types of arguments must match the format. Chapter 2 introduces additional types and their formats.

### main.c

```c
#include <stdio.h>

int main(void) {
    printf("Count: %d\n", 3);
    printf("Progress: 100%%\n");
    return 0;
}
```

Output:

```text
Count: 3
Progress: 100%
```

The first call substitutes 3 for %d and then starts a new line. The second prints a percent sign from %%. A newline is part of the output string; it does not come automatically from printf. Incorrect format/argument combinations can cause undefined behavior, so read format warnings carefully.

**Watch for:** Writing /n uses a forward slash and the letter n. It is not the newline escape. Also, avoid using user-provided text as the format string; print text through a suitable fixed format instead.

**Check:** What does printf("%d%%", 25) print?

1. 25%
2. 25%%
3. %d%

<details><summary>Answer</summary>

25%. The %d consumes 25; %% contributes one literal percent sign.

</details>

**Try:** Print two labeled integer values on separate lines. Include a literal percent sign in one line.

### References and help

- [C reference: printf family](https://en.cppreference.com/w/c/io/fprintf.html) — Read conversion specifiers, required argument types, and the return value.
- [Linux manual: printf(3)](https://man7.org/linux/man-pages/man3/printf.3.html) — Use SYNOPSIS, conversion specifications, RETURN VALUE, and STANDARDS; note POSIX extensions.

**Use the documentation (optional):** What does printf return on success, and how many characters does printf("Hi!\n") report?

<details><summary>Compare your answer</summary>

On success printf returns the number of characters transmitted, excluding the terminating null byte. H, i, !, and the newline make four. A negative result reports an output or encoding error.

</details>

Run from the repository root:

```sh
make example EXAMPLE=first-program-3
```

## 1.4 Reading compiler errors

A diagnostic is evidence about where the compiler became unable to understand or accept your source. Read the first error, inspect its location, and make one small correction before compiling again.

Consider `printf("Hello")` followed by `return 0;`. The call is missing its semicolon. The compiler may point at return because that is where it discovers the previous statement was not terminated. Warnings describe suspicious constructs that a compiler may still translate. Keep warnings visible: a successful build does not establish correct behavior. Linking failures, such as an undefined function reference, belong to a later stage.

### main.c

```c
#include <stdio.h>

int main(void) {
    printf("Hello\n");
    return 0;
}
```

Output:

```text
Hello
```

This is the corrected program. Remove the semicolon after printf in the editor and run it to observe a real compiler diagnostic. Restore the semicolon and rerun. If several errors appear, start at the first; later messages can be consequences of the same initial mistake. Exact diagnostic wording depends on compiler version.

**Watch for:** Do not change a large number of lines to silence a list of errors. A small edit-and-recompile cycle makes it easier to connect a cause with its effect.

**Check:** The compiler points at return, but the preceding printf has no semicolon. What should you inspect first?

1. The preceding statement
2. The browser storage
3. The output font

<details><summary>Answer</summary>

The preceding statement. The reported location is where parsing failed, which can follow the actual mistake.

</details>

**Try:** Create the missing-semicolon error, read it, fix it, and explain why its location may be one line later.

### References and help

- [GCC manual: warning options](https://gcc.gnu.org/onlinedocs/gcc/Warning-Options.html) — Look up a diagnostic option and the conditions it reports.

Run from the repository root:

```sh
make example EXAMPLE=first-program-4
```

## 1.5 C, WebAssembly, and standard input/output

The browser lab is a C environment with a limited operating-system interface. It is useful to know what belongs to the C language, what belongs to the runtime, and what the page itself provides.

The editor contains source. Run code compiles and executes it in a worker so the page remains responsive. Console shows program output and diagnostics. Input supplies text before execution; it is not an interactive terminal that waits for you to type midway through the run. Later exercises will read it. Check output compares observable results with practice cases. It does not prove that an algorithm is appropriate or memory is managed correctly.

### Source becomes a runnable program

Preprocessing, compilation, linking, and execution have different jobs.

Start with main.c. Preprocessing expands includes and macros. Compilation translates the resulting C into object code. The linker resolves references between objects and libraries and produces a program. A native operating system or a Wasm runtime executes the result. A successful translation is separate from a successful run.

The target determines whether the final program is native code or a WebAssembly module.

### main.c

```c
#include <stdio.h>

int main(void) {
    printf("This program runs in the browser.\n");
    return 0;
}
```

Output:

```text
This program runs in the browser.
```

This program needs only standard output. A Wasm module is generated and executed locally. Your edited source can be saved in this browser, but a program’s temporary files do not become permanent course data. Use Export for a copy you can keep or move to Browser Linux. Stop terminates the running worker, including a program stuck in a loop.

**Watch for:** Native Linux processes, sockets, and C threads are not supplied by this lab. Chapters that need those capabilities identify Browser Linux as their execution environment; they are still readable on a tablet.

**Check:** When should you supply input for the current browser runner?

1. Before pressing Run code
2. Only after the program asks in Console

<details><summary>Answer</summary>

Before pressing Run code. The runner passes the Input text at the start. It does not offer an interactive stdin prompt.

</details>

**Try:** Open the chapter’s greeting exercise. Edit, run, check, and export your first C file.

### References and help

- [WebAssembly concepts](https://developer.mozilla.org/en-US/docs/WebAssembly/Guides/Concepts) — Distinguish source code, a Wasm module, and the host/runtime that supplies its environment.
- [C reference: input/output](https://en.cppreference.com/w/c/io.html) — Compare stream modes, positioning, error indicators, and formatted I/O.

Run from the repository root:

```sh
make example EXAMPLE=first-program-5
```

## 1.6 Finding and reading C documentation

Find an answer in C documentation, turn it into a prediction, and check it with a small program.

A function reference describes a contract: the header to include, the arguments to supply, the result it returns, and conditions you must handle. Start with one concrete question. For `printf`, ask “What does it return?” before trying to memorize the complete format table. C17 is this course’s baseline; a reference can also describe newer C revisions, POSIX facilities, or Linux extensions. Check those labels before assuming an API or format is available in the browser.

### Choose the right entry

Use the online references below in this browser lab. Section 3 of Linux manuals describes C library functions; section 1 describes commands. A shell can also have a printf builtin with separate help. The example manual commands below are optional reference instructions for systems that have man pages installed; the hosted Browser Linux image does not include them.

```text
man 3 printf
man 1 printf
man -k printf
```

### Read the contract before the examples

In SYNOPSIS, find stdio.h and the function’s int return type. DESCRIPTION explains conversion specifiers and the types they require. RETURN VALUE gives the success and failure results. ERRORS and STANDARDS add failure conditions and portability details. You do not need to understand every pointer annotation yet; pointers are covered later.

```text
int printf(const char *restrict format, ...);
```

### Search, predict, then verify

Use your browser’s Find feature to locate RETURN VALUE in the online printf reference. Read that success returns the transmitted character count and output or encoding failure returns a negative value. Predict the result for Hi! followed by a newline, then run the example. In an optional man/less environment, /RETURN VALUE searches, n finds the next match, and q quits; man -k searches installed descriptions.

### main.c

```c
#include <stdio.h>

int main(void) {
    int written = printf("Hi!\n");
    printf("count=%d\n", written);
    return 0;
}
```

Output:

```text
Hi!
count=4
```

The first call writes H, i, !, and a newline: four characters. The terminating null byte in the C string is not transmitted. int written stores that return value; the next chapter develops variables and types. The second call prints the stored count using %d. Read printf’s own return contract, rather than assuming every C function uses zero to mean success.

**Watch for:** Do not confuse printf(1), the command-line utility, with printf(3), the C library function. Match format specifiers to argument types, and check whether a documented facility belongs to ISO C, POSIX, or a particular implementation. A reference describing a feature does not establish support in every compiler or runtime.

**Check:** After printf("Hi!\n") succeeds, which return value does its documentation specify?

1. 4: three visible characters and the newline
2. 5: including the string’s terminating null byte
3. 0: every C function returns zero on success

<details><summary>Answer</summary>

4: three visible characters and the newline. printf counts characters transmitted, including the newline and excluding the terminating null byte. Its failure result is negative.

</details>

**Try:** Use the printf reference to predict the count for "C\n", change the first call, and run it. Then find how to print a literal percent sign, include one in the message, and explain why the source spelling and output length differ.

### References and help

- [C reference: printf family](https://en.cppreference.com/w/c/io/fprintf.html) — Read conversion specifiers, required argument types, and the return value.
- [Linux manual: printf(3)](https://man7.org/linux/man-pages/man3/printf.3.html) — Use SYNOPSIS, conversion specifications, RETURN VALUE, and STANDARDS; note POSIX extensions.
- [Linux manual: printf(1)](https://man7.org/linux/man-pages/man1/printf.1.html) — Compare the command-line utility with the C library function in section 3.

Run from the repository root:

```sh
make example EXAMPLE=first-program-6
```

## Chapter practice

Edit `native/exercises/hello.c`, then run:

```sh
make exercise EXERCISE=hello
```

Chapter workspace command: `make chapter CHAPTER=first-program`.

Generated from dist/part1.js by tools/sync_readings.cjs. Full reading: https://snowch.github.io/c-foundry/#/chapter/first-program
