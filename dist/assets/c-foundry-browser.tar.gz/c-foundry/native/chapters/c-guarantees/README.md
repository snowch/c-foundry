# Chapter 32: What C guarantees

Part 7: Writing portable C. Teaching baseline: C17.

Audit C’s behavior and numeric boundaries: conversions, checked arithmetic, exceptional integer operations, and finite floating-point calculations.

## Outcomes

- Classify defined, implementation-defined, unspecified, and undefined behavior.
- Respect object lifetime, effective types, and alignment.
- Compare optimized builds only on valid programs.
- Validate signed/unsigned comparisons and narrowing before values change meaning.
- Reject overflow, invalid division/remainder, and unrepresentable negation before evaluating them.
- Choose a floating-point error policy for rounding, NaN, infinity, and underflow.

## 32.1 Defined, implementation-defined, unspecified, and undefined behavior

Different kinds of latitude in C require different responses. Undefined behavior is not just another documented platform choice.

Also editable and runnable inline in the browser course. This probe runs with the inline browser’s fixed C17 toolchain. Use Browser Linux for GCC/Clang comparisons and supported language modes.

Defined behavior follows the language contract. Implementation-defined behavior requires an implementation’s documented choice, such as relevant integer characteristics. Unspecified behavior permits a set of allowed choices without requiring the same choice every time, such as many operand evaluation orders. Undefined behavior imposes no requirements. The executable uses defined operations and reports a guaranteed minimum property, avoiding deliberate invalid accesses.

### Unsigned wrap and signed overflow are different

Only the unsigned result is defined to wrap modulo its type’s range.

Adding unsigned 1 to UINT_MAX yields unsigned zero by modular arithmetic. Evaluating signed INT_MAX plus signed 1 exceeds the signed int range and has undefined behavior. Do not evaluate that signed expression to test whether it overflowed; check beforehand.

No particular int width is assumed.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
  unsigned wrapped = UINT_MAX;
  wrapped += 1;
  printf("char_bits_at_least8=%d unsigned_wrap=%u\n", CHAR_BIT >= 8, wrapped);
  return 0;
}
```

Output:

```text
char_bits_at_least8=1 unsigned_wrap=0
```

Unsigned arithmetic is modulo its type’s range. That guarantee does not extend to overflowing signed arithmetic.

**Watch for:** An observed compiler result cannot turn undefined behavior into a portable rule.

**Check:** Is signed overflow merely an implementation-defined wrap choice?

1. No, it is undefined behavior in standard C
2. Yes

<details><summary>Answer</summary>

No, it is undefined behavior in standard C. Standard unsigned and signed arithmetic have different overflow contracts.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/c-guarantees/1). In main.c, change wrapped += 1; to wrapped += 2;. Run code and compare unsigned_wrap=. Which bound gives the starting value? How does the rule for unsigned addition let you predict the result without knowing the exact width of unsigned?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: behavior categories (included in the explanation above) — Distinguish undefined, unspecified, and implementation-defined behavior.
- Course notes: numeric limits (included in the explanation above) — Find the macros that describe the selected implementation’s ranges.

**Optional further reading (internet required):**

- [C reference: behavior categories](https://en.cppreference.com/w/c/language/behavior.html)
- [C reference: numeric limits](https://en.cppreference.com/w/c/types/limits.html)

Native source: `native/examples/c-guarantees-1/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=c-guarantees-1 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 32.2 Integer representation, alignment, object lifetime, and aliasing

A pointer’s numeric appearance does not establish alignment, type compatibility, or object lifetime. Use character access and memcpy for representation transfers.

Also editable and runnable inline in the browser course. This probe runs with the inline browser’s fixed C17 toolchain. Use Browser Linux for GCC/Clang comparisons and supported language modes.

The example copies an unsigned integer’s object representation into an unsigned-char array and back into a compatible object. Access through unsigned char may inspect object bytes; casting arbitrary byte storage to a wider pointer can violate alignment and effective-type rules. None of these operations extend an object’s lifetime or permit access after free.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
  uint32_t source = UINT32_C(0x12345678), copy = 0;
  unsigned char bytes[sizeof source];
  memcpy(bytes, &source, sizeof bytes);
  memcpy(&copy, bytes, sizeof copy);
  printf("roundtrip=%d bytes=%zu\n", copy == source, sizeof bytes);
  return 0;
}
```

Output:

```text
roundtrip=1 bytes=4
```

On the supported eight-bit-byte targets, uint32_t occupies four bytes. The test compares restored value rather than assuming a host byte order.

**Watch for:** A byte-for-byte native representation round trip is not a portable external file encoding.

**Check:** Why avoid casting this arbitrary byte array to uint32_t *?

1. memcpy cannot copy integer values
2. Alignment and object-type requirements may not be satisfied

<details><summary>Answer</summary>

Alignment and object-type requirements may not be satisfied. memcpy transfers representation bytes without requiring a misaligned typed access.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/c-guarantees/2). In main.c, change the source from 0x12345678 to 0x12345679. Run code and compare roundtrip= and bytes=. What does copying the object representation establish on this target? A portable file format still needs an explicit byte order.

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: behavior categories (included in the explanation above) — Distinguish undefined, unspecified, and implementation-defined behavior.
- [Read free(3)](../../manuals/free.3.txt) (included) — Check valid pointer arguments and access after deallocation.
- [Read memcpy(3)](../../manuals/memcpy.3.txt) (included) — Check byte counts, valid object ranges, and the non-overlap requirement.

**Optional further reading (internet required):**

- [C reference: behavior categories](https://en.cppreference.com/w/c/language/behavior.html)

Native source: `native/examples/c-guarantees-2/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=c-guarantees-2 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 32.3 Why code can behave differently under optimization

Optimizers may transform valid programs while preserving their required observable behavior. They need not preserve a guessed result after undefined behavior.

Also editable and runnable inline in the browser course. This probe runs with the inline browser’s fixed C17 toolchain. Use Browser Linux for GCC/Clang comparisons and supported language modes.

The fixture uses unsigned fixed-width arithmetic with a defined wrap result and a bounded representable sum. Compile it at multiple optimization levels and compare those outputs. If a different program changes behavior under optimization, audit its language contracts, races, and uninitialized state before treating the difference as an optimizer bug.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
  uint32_t x = UINT32_MAX;
  x += UINT32_C(1);
  unsigned sum = 0;
  for (unsigned i = 1; i <= 4; ++i)
    sum += i;
  printf("wrapped=%u sum=%u\n", (unsigned)x, sum);
  return 0;
}
```

Output:

```text
wrapped=0 sum=10
```

The required result remains zero and ten under valid optimizing transformations. The native fixture requests -O2; the inline runner uses its fixed unoptimized C17 build. Compare native -O0 and -O2 builds to investigate optimization.

**Watch for:** Turning optimization off can hide a defect without fixing it.

**Check:** What should be checked first after an optimization-sensitive failure?

1. Lifetime, bounds, aliasing, initialization, and synchronization
2. Whether -O0 appears to work

<details><summary>Answer</summary>

Lifetime, bounds, aliasing, initialization, and synchronization. A valid source contract is the basis for expecting preserved behavior.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/c-guarantees/3). In main.c, change x += UINT32_C(1); to x += UINT32_C(2);. Run code. Compare wrapped= and sum=. Which value changes according to the defined uint32_t wrap rule, even if a native compiler later optimizes the loop?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: behavior categories (included in the explanation above) — Distinguish undefined, unspecified, and implementation-defined behavior.
- Course notes: numeric limits (included in the explanation above) — Find the macros that describe the selected implementation’s ranges.

**Optional further reading (internet required):**

- [C reference: behavior categories](https://en.cppreference.com/w/c/language/behavior.html)
- [C reference: numeric limits](https://en.cppreference.com/w/c/types/limits.html)

Native source: `native/examples/c-guarantees-3/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=c-guarantees-3 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 32.4 Signed/unsigned comparisons and integer promotions

Before evaluating a mixed-type expression, determine the promoted operand types. A negative signed value can become a large unsigned value before comparison.

For operands of type int and unsigned int, the usual arithmetic conversions convert the int operand to unsigned int. Thus the mathematical comparison −1 < 1 differs from its mixed-type C counterpart. The program makes that conversion explicit so strict compiler warnings remain enabled. For index validation, first reject negatives, then compare in an unsigned type that can represent both nonnegative operands. Small integer types are promoted too: uint8_t operands commonly add as int, so a later narrowing cast is a separate operation.

### main.c

```c
#include <stdio.h>
#include <stdbool.h>
#include <limits.h>
#include <stdint.h>
#include <stddef.h>


int main(void) {
    int negative=-1;unsigned limit=1;
    unsigned converted=(unsigned)negative;
    bool mathematical_less=negative<0||(uintmax_t)negative<(uintmax_t)limit;
    size_t count=3;bool valid_index=negative>=0&&(uintmax_t)negative<(uintmax_t)count;
    uint8_t a=250,b=10;int promoted=a+b;
    printf("converted_less=%d mathematical_less=%d valid_index=%d\n",converted<limit,mathematical_less,valid_index);
    printf("promoted_sum=%d narrowed_sum=%u\n",promoted,(unsigned)(uint8_t)promoted);
    return 0;
}
```

Output:

```text
converted_less=0 mathematical_less=1 valid_index=0
promoted_sum=260 narrowed_sum=4
```

Converting −1 to unsigned produces UINT_MAX, which is not less than one. The guarded mathematical comparison correctly says a negative integer is smaller than an unsigned nonnegative value, while the index check rejects it. The two uint8_t operands promote to int and sum to 260; casting that result to uint8_t then reduces it modulo 256 to four.

### Conversion can happen before or after arithmetic

Which conversion turns −1 into an unsigned value, and which turns 260 into 4?

The starter explicitly casts int minus one to unsigned int, producing UINT_MAX. Comparing that value with unsigned one is false; an uncast mixed comparison would apply the same conversion here. In the uint8_t example, 250 and 10 are added as int to produce 260, then conversion back to uint8_t produces 4 modulo 256. The narrowing occurs after the addition.

This example has uint8_t and an int type that represents all its values. UINT_MAX depends on unsigned int width; signed overflow has different rules.

**Watch for:** Casting a negative index to size_t does not validate it. Also, signed/unsigned rules depend on rank and representability; a wider signed type can sometimes represent every value of the unsigned operand.

**Check:** On these targets, what is the type of the sum of two uint8_t operands?

1. uint8_t, so addition itself must wrap at 255
2. int after integer promotion

<details><summary>Answer</summary>

int after integer promotion. An int can represent every uint8_t value on the supported targets, so both operands promote to int before addition.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/c-guarantees/4). In main.c, change negative from -1 to 1 and b from 10 to 5. Run code and compare converted_less=, mathematical_less=, valid_index=, promoted_sum=, and narrowed_sum=. Why do 255 and 260 differ when narrowed to uint8_t?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: conversions (included in the explanation above) — Check integer promotions, usual arithmetic conversions, and narrowing.
- Course notes: behavior categories (included in the explanation above) — Distinguish undefined, unspecified, and implementation-defined behavior.
- Course notes: numeric limits (included in the explanation above) — Find the macros that describe the selected implementation’s ranges.

**Optional further reading (internet required):**

- [C reference: conversions](https://en.cppreference.com/w/c/language/conversion.html)
- [C reference: behavior categories](https://en.cppreference.com/w/c/language/behavior.html)
- [C reference: numeric limits](https://en.cppreference.com/w/c/types/limits.html)

**Use the documentation (optional):** Does an unsigned operand always convert a signed operand to unsigned, regardless of their ranks and ranges?

<details><summary>Compare your answer</summary>

No. Integer promotions and the usual arithmetic conversions depend on rank and representable range. Work through the types and values before deciding how the comparison is evaluated.

</details>

Native source: `native/examples/c-guarantees-4.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=c-guarantees-4 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 32.5 Narrowing conversions and range-checked casts

A cast asks for a conversion; it does not promise that the converted value retains the original meaning. Validate a destination’s range before narrowing.

Converting an integer to an unsigned type reduces it modulo that type’s range. In the course’s C17 baseline, an out-of-range conversion to a signed integer type instead has an implementation-defined result or can raise an implementation-defined signal. C23 changes integer conversion rules, but wrapping still may violate the application’s intent. Signed arithmetic overflow remains undefined: conversion rules do not make overflowing signed arithmetic valid. This helper accepts only values in SCHAR_MIN..SCHAR_MAX, assigns after validation, and leaves the output unchanged on rejection. Exact-width uint8_t is an explicit supported-target requirement.

### Check the destination range before converting

A defined conversion can still violate the application’s input policy.

For an implementation providing uint8_t, the representable range is zero through 255. A checked conversion accepts input 200 and converts it. It rejects input 300 before casting. Converting 300 directly to uint8_t would produce 44 modulo 256; rejection is the checked API’s chosen contract.

This assumes uint8_t exists. It is not a claim that every narrowing conversion is undefined.

### main.c

```c
#include <stdio.h>
#include <stdbool.h>
#include <limits.h>
#include <stdint.h>
#include <stddef.h>

bool to_signed_char(int value,signed char *out){
    if(value<SCHAR_MIN||value>SCHAR_MAX)return false;
    *out=(signed char)value;return true;
}

int main(void) {
    _Static_assert(CHAR_BIT==8,"This fixture requires eight-bit bytes");
    signed char out=7;bool accepted=to_signed_char(130,&out);
    printf("unsigned_narrow=%u signed_rejected=%d output=%d\n",(unsigned)(uint8_t)260,!accepted,(int)out);
    bool low=to_signed_char(SCHAR_MIN,&out),high=to_signed_char(SCHAR_MAX,&out);
    printf("endpoints_accepted=%d\n",low&&high);
    return 0;
}
```

Output:

```text
unsigned_narrow=4 signed_rejected=1 output=7
endpoints_accepted=1
```

The unsigned conversion is defined and yields four. The signed conversion of 130 is never attempted on these eight-bit-byte targets: the guard rejects it and retains seven. Both representable signed endpoints are accepted. The example does not assume a particular implementation-defined out-of-range signed result.

**Watch for:** Checking whether a value fits after casting it checks the already changed value. Unsigned-to-signed, integer-to-floating, and floating-to-integer conversions also have distinct rules; the integer narrowing rule is not a universal conversion policy.

**Check:** When should a range check for a narrowing conversion run?

1. Before converting, using the original value
2. After converting, using only the narrowed value

<details><summary>Answer</summary>

Before converting, using the original value. The original information may be lost or the conversion may already have triggered an invalid or implementation-defined result.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/c-guarantees/5). In main.c, change the first to_signed_char argument from 130 to SCHAR_MAX. Run code. Compare signed_rejected= and output= with the earlier rejected request. Which accepted boundary can safely overwrite the original 7?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: conversions (included in the explanation above) — Check integer promotions, usual arithmetic conversions, and narrowing.
- Course notes: numeric limits (included in the explanation above) — Find the macros that describe the selected implementation’s ranges.

**Optional further reading (internet required):**

- [C reference: conversions](https://en.cppreference.com/w/c/language/conversion.html)
- [C reference: numeric limits](https://en.cppreference.com/w/c/types/limits.html)

Native source: `native/examples/c-guarantees-5.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=c-guarantees-5 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 32.6 Checked addition, subtraction, and multiplication

Reject an unrepresentable signed result before evaluating the operation. Checking for wrap after signed overflow is too late.

The helpers compare operands against safe rearrangements of INT_MIN and INT_MAX. Addition and subtraction split by the second operand’s sign. Multiplication splits by both signs and avoids dividing by zero through short-circuit conditions. Every guard calculation is itself representable, including the most-negative operand. Callers supply a valid int output object; rejection leaves it unchanged. These are portable C17 checks, not reliance on a compiler’s observed wrap behavior or a cast to a merely assumed wider type.

### Unsigned wrap and signed overflow are different

Only the unsigned result is defined to wrap modulo its type’s range.

Adding unsigned 1 to UINT_MAX yields unsigned zero by modular arithmetic. Evaluating signed INT_MAX plus signed 1 exceeds the signed int range and has undefined behavior. Do not evaluate that signed expression to test whether it overflowed; check beforehand.

No particular int width is assumed.

### main.c

```c
#include <stdio.h>
#include <stdbool.h>
#include <limits.h>
#include <stdint.h>
#include <stddef.h>

bool checked_add(int a,int b,int *out){
    if((b>0&&a>INT_MAX-b)||(b<0&&a<INT_MIN-b))return false;
    *out=a+b;return true;
}
bool checked_subtract(int a,int b,int *out){
    if((b>0&&a<INT_MIN+b)||(b<0&&a>INT_MAX+b))return false;
    *out=a-b;return true;
}
bool checked_multiply(int a,int b,int *out){
    if(a>0){if((b>0&&a>INT_MAX/b)||(b<0&&b<INT_MIN/a))return false;}
    else if(a<0){if((b>0&&a<INT_MIN/b)||(b<0&&a<INT_MAX/b))return false;}
    *out=a*b;return true;
}

int main(void) {
    int value=77;bool added=checked_add(INT_MAX,1,&value);
    printf("add_rejected=%d preserved=%d\n",!added,value==77);
    bool subtracted=checked_subtract(INT_MIN,1,&value);
    printf("subtract_rejected=%d preserved=%d\n",!subtracted,value==77);
    bool multiplied=checked_multiply(-7,6,&value);
    printf("multiply_accepted=%d result=%d\n",multiplied,value);
    return 0;
}
```

Output:

```text
add_rejected=1 preserved=1
subtract_rejected=1 preserved=1
multiply_accepted=1 result=-42
```

INT_MAX+1 and INT_MIN−1 are rejected without evaluation, retaining the sentinel 77. The valid product −42 is then stored. The sign branches also handle multiplication by zero without dividing by zero. Boundary tests must cover all operand-sign combinations, not only two positive operands.

**Watch for:** A test such as a+b<a may itself already execute undefined signed overflow. A larger integer type is useful only when its range is actually sufficient for the operands and intermediate result.

**Check:** Can a signed-overflow check safely evaluate a+b first and inspect the result?

1. Yes, if the result is stored immediately
2. No, the guard must run before the overflowing expression

<details><summary>Answer</summary>

No, the guard must run before the overflowing expression. Undefined behavior has already occurred once the unrepresentable signed operation is evaluated.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/c-guarantees/6). In main.c, change the multiply arguments from -7 and 6 to INT_MAX and 2. Run code and compare multiply_accepted= and result=. Why does the output retain 77 after a rejected multiplication?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: behavior categories (included in the explanation above) — Distinguish undefined, unspecified, and implementation-defined behavior.
- Course notes: numeric limits (included in the explanation above) — Find the macros that describe the selected implementation’s ranges.

**Optional further reading (internet required):**

- [C reference: behavior categories](https://en.cppreference.com/w/c/language/behavior.html)
- [C reference: numeric limits](https://en.cppreference.com/w/c/types/limits.html)

Native source: `native/examples/c-guarantees-6.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=c-guarantees-6 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 32.7 Division, remainder, and negating INT_MIN

Zero is not the only dangerous divisor. On two’s-complement targets, INT_MIN / -1 and -INT_MIN also require an unrepresentable positive result.

C17 integer division truncates toward zero, and a nonzero remainder has the dividend’s sign. Division or remainder by zero is invalid. If the quotient is not representable, both / and % have undefined behavior, even when the mathematical remainder would be zero. Negating INT_MIN is invalid when its positive counterpart exceeds INT_MAX. The guards use value < -INT_MAX, which is itself safe and respects C17 implementations with a symmetric signed range; the supplied native and Wasm targets have an asymmetric two’s-complement range. The division helper borrows two distinct live int output objects and writes neither on rejection.

### main.c

```c
#include <stdio.h>
#include <stdbool.h>
#include <limits.h>
#include <stdint.h>
#include <stddef.h>

bool checked_negate(int value,int *out){
    if(value < -INT_MAX)return false;
    *out=-value;return true;
}
bool checked_divrem(int a,int b,int *quotient,int *remainder){
    if(b==0||(b==-1&&a < -INT_MAX))return false;
    int q=a/b,r=a%b;
    *quotient=q;*remainder=r;return true;
}

int main(void) {
    int quotient=77,remainder=88,negated=99;
    bool zero=checked_divrem(7,0,&quotient,&remainder);
    bool edge=checked_divrem(INT_MIN,-1,&quotient,&remainder);
    bool negation=checked_negate(INT_MIN,&negated);
    printf("zero_rejected=%d min_div_rejected=%d min_negate_rejected=%d\n",!zero,!edge,!negation);
    if(!checked_divrem(-7,3,&quotient,&remainder))return 1;
    printf("quotient=%d remainder=%d\n",quotient,remainder);
    return 0;
}
```

Output:

```text
zero_rejected=1 min_div_rejected=1 min_negate_rejected=1
quotient=-2 remainder=-1
```

All three hazardous cases are rejected on the supported two’s-complement targets. The valid division produces quotient −2 and remainder −1: −7 = (−2)·3 + (−1). No demonstration deliberately performs an undefined negation, division, or remainder.

**Watch for:** Replacing division with remainder does not make the INT_MIN/-1 case safe. Also, abs(INT_MIN) has the same representability problem when the positive result cannot fit in int.

**Check:** On these targets, is INT_MIN % -1 valid just because the mathematical remainder is zero?

1. No: the unrepresentable quotient also makes % invalid
2. Yes: only division can overflow

<details><summary>Answer</summary>

No: the unrepresentable quotient also makes % invalid. C defines both operations in terms of a representable quotient; the exceptional pair invalidates both.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/c-guarantees/7). In main.c, change checked_divrem(-7,3,&quotient,&remainder) to checked_divrem(7,-3,&quotient,&remainder). Run code and compare quotient= and remainder=. Check that divisor × quotient + remainder gives the input for each sign combination.

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: behavior categories (included in the explanation above) — Distinguish undefined, unspecified, and implementation-defined behavior.
- Course notes: numeric limits (included in the explanation above) — Find the macros that describe the selected implementation’s ranges.

**Optional further reading (internet required):**

- [C reference: behavior categories](https://en.cppreference.com/w/c/language/behavior.html)
- [C reference: numeric limits](https://en.cppreference.com/w/c/types/limits.html)

Native source: `native/examples/c-guarantees-7.c`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=c-guarantees-7 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 32.8 Floating-point rounding, cancellation, and tolerances

Floating-point arithmetic approximates many real-number operations. A type with more precision still cannot represent every decimal fraction exactly.

This native experiment explicitly requires binary64 double and round-to-nearest. It adds stored approximations of 0.1 and 0.2, prints enough digits to reveal their result, and compares with a combined absolute/relative tolerance. Absolute tolerance matters near zero; relative tolerance scales with magnitude. The small nearly_equal helper rejects nonfinite values and restricts its domain so its own subtraction and multiplication cannot overflow. A tolerance is an application error budget, not a universal replacement for equality or a sorting comparator. The repository command links the native math library with -lm; headers alone do not provide that linker step on Linux.

### main.c

```c
#include <stdio.h>
#include <stdbool.h>
#include <limits.h>
#include <stdint.h>
#include <stddef.h>
#include <math.h>
#include <float.h>
#include <fenv.h>
_Static_assert(FLT_RADIX==2&&DBL_MANT_DIG==53&&DBL_MAX_EXP==1024,
               "This native demonstration requires binary64 double");

bool nearly_equal(double a,double b,double absolute,double relative){
    if(!isfinite(a)||!isfinite(b)||!isfinite(absolute)||!isfinite(relative)||
       absolute<0.0||relative<0.0)return false;
    /* Domain for this teaching helper: finite |a|,|b|,relative <= 1. */
    if(fabs(a)>1.0||fabs(b)>1.0||relative>1.0)return false;
    double scale=fmax(fabs(a),fabs(b));
    return fabs(a-b)<=fmax(absolute,relative*scale);
}

int main(void) {
    int previous=fegetround();if(previous<0||fesetround(FE_TONEAREST)!=0)return 1;
    volatile double a=0.1,b=0.2,big=0x1p53,one=1.0;
    double sum=a+b;double lost=(big+one)-big;
    printf("sum=%.17g exact=%d close=%d\n",sum,sum==0.3,nearly_equal(sum,0.3,1e-15,1e-12));
    printf("small_increment_lost=%d\n",lost==0.0);
    if(fesetround(previous)!=0)return 1;
    return 0;
}
```

Output:

```text
sum=0.30000000000000004 exact=0 close=1
small_increment_lost=1
```

The stored sum differs from the stored 0.3 value but falls inside the stated tolerance. At 2^53, adding one rounds back to the same binary64 value under round-to-nearest, so subtracting the large value returns zero. Printing more decimal places exposes approximation; it does not restore lost information.

**Watch for:** Near-equality is generally not transitive and must not define qsort ordering. The safe domain of this helper is deliberately narrower than all finite doubles; a general-purpose comparison must handle overflow in its own calculations.

**Check:** Should one fixed epsilon be used for every magnitude and application?

1. Yes, DBL_EPSILON is a universal error allowance
2. No, choose absolute/relative tolerances from the problem’s error budget

<details><summary>Answer</summary>

No, choose absolute/relative tolerances from the problem’s error budget. DBL_EPSILON describes spacing near one, not every accumulated error or acceptable application difference.

</details>

**Try:** Edit the example in Browser Linux.  In native/examples/c-guarantees-8/main.c, change one from 1.0 to 2.0 and repeat the terminal run. Compare small_increment_lost= with the first run while checking sum=, exact=, and close=. What does the observed spacing near 2^53 allow on this target?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: floating-point limits (included in the explanation above) — Find precision, exponent-range, and subnormal-support macros.
- [Read fenv(3)](../../manuals/fenv.3.txt) (included) — Check rounding modes and implementation support before relying on them.

**Optional further reading (internet required):**

- [C reference: floating-point limits](https://en.cppreference.com/w/c/types/limits.html)

Native source: `native/examples/c-guarantees-8/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=c-guarantees-8 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 32.9 NaN, infinity, and finite numeric input

A floating-point result can be finite, infinite, or NaN on the supported IEEE-style targets. Test the category you require rather than relying on ordinary comparisons.

The example obtains special values from the standard NAN and INFINITY macros, not from invalid integer arithmetic or an assumed floating divide-by-zero extension. A quiet NaN is unordered: comparisons such as x==x are false, so x==NAN is not a NaN test. Use isnan, isinf, and isfinite. strtod accepts spellings such as nan and inf; a database field that requires finite numbers must reject them explicitly. This strict parser also rejects ERANGE, no conversion, and trailing input before assigning its output.

### main.c

```c
#include <stdio.h>
#include <stdbool.h>
#include <limits.h>
#include <stdint.h>
#include <stddef.h>
#include <math.h>
#include <float.h>
#include <fenv.h>
_Static_assert(FLT_RADIX==2&&DBL_MANT_DIG==53&&DBL_MAX_EXP==1024,
               "This native demonstration requires binary64 double");
#include <stdlib.h>
#include <errno.h>
#if !defined(NAN)||!defined(INFINITY)
#error "This example requires NaN and infinity support"
#endif

bool parse_finite(const char *text,double *out){
    char *end;errno=0;double value=strtod(text,&end);
    if(end==text||*end!='\0'||errno==ERANGE||!isfinite(value))return false;
    *out=value;return true;
}

int main(void) {
    double quiet=NAN,infinite=INFINITY,value=7.0;
    printf("nan_self_equal=%d nan_classified=%d infinity_classified=%d\n",quiet==quiet,isnan(quiet)!=0,isinf(infinite)!=0);
    bool bad=parse_finite("nan",&value);printf("nan_rejected=%d preserved=%d\n",!bad,value==7.0);
    bool good=parse_finite("-1.25",&value);printf("finite_accepted=%d value=%.2f\n",good,value);
    return 0;
}
```

Output:

```text
nan_self_equal=0 nan_classified=1 infinity_classified=1
nan_rejected=1 preserved=1
finite_accepted=1 value=-1.25
```

The classification macros return nonzero for the matching category. Rejecting nan retains the earlier value seven; the valid finite literal then replaces it with −1.25. Parse success is not the same as meeting a finite-only schema or fitting a later integer conversion.

### A numeric spelling can still violate the field policy

Why must the parser test isfinite after strtod succeeds?

Why must the parser test isfinite after strtod succeeds? strtod result, complete field and no range error?. Finite result: -1.25. Accept; assign output. finite_accepted=1 value=-1.25; Nonfinite result: nan. Reject; preserve output 7.0. nan_rejected=1 preserved=1. The parser also rejects empty conversion and trailing input. Quiet NaN is unordered: nan==nan is false. Use isnan/isinf/isfinite rather than equality with NAN.

The parser also rejects empty conversion and trailing input. Quiet NaN is unordered: nan==nan is false. Use isnan/isinf/isfinite rather than equality with NAN. Illustration of the supplied example; edits do not update this picture.

**Watch for:** A check such as value < minimum || value > maximum can miss NaN because both ordered comparisons are false. Do not compile these classification examples with -ffast-math, whose assumptions can invalidate NaN/infinity reasoning.

**Check:** Which check establishes a finite value for a finite-only field?

1. isfinite(value)
2. value == value, which also accepts infinity

<details><summary>Answer</summary>

isfinite(value). Self-equality excludes quiet NaN but still permits infinities; isfinite excludes both categories.

</details>

**Try:** Edit the example in Browser Linux.  In native/examples/c-guarantees-9/main.c, change the first parse_finite argument from "nan" to "inf" and rename nan_rejected= to inf_rejected=. Repeat the terminal run. Which fields show that the parser kept 7.0 after rejection and accepted the later finite value?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- [Read sqrt(3)](../../manuals/sqrt.3.txt) (included) — sqrt, sqrtf, sqrtl - square root function
- [Read strtod(3)](../../manuals/strtod.3.txt) (included) — Check endptr, range errors, and acceptance of infinity/NaN before enforcing a finite-input policy.

**Optional further reading (internet required):**

- [C reference: mathematical functions](https://en.cppreference.com/w/c/numeric/math.html)

Native source: `native/examples/c-guarantees-9/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=c-guarantees-9 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 32.10 Floating-point underflow, subnormals, and range errors

Floating-point underflow is a loss of tiny-magnitude range or precision, not unsigned integer wraparound. Gradual subnormals can extend the range below the smallest normal value.

DBL_MIN is the smallest positive normal double, not the most negative value and not the smallest positive subnormal. On the explicitly required binary64 target with gradual underflow, nextafter(0,1) produces the smallest positive representable value. This experiment uses specified math-library functions to scale values, establishes round-to-nearest, and classifies results. A sufficiently small result rounds to zero; subnormals are finite but have less relative precision. errno and floating exceptions have math_errhandling-dependent contracts, so classification and application policy must not assume every implementation reports them identically.

### Tiny positive results can become subnormal or zero

Binary64 gradual underflow extends below DBL_MIN without unsigned-style wraparound.

Read the boxes in increasing value, starting at zero. Zero is followed by the smallest positive subnormal, two to the power minus one thousand seventy-four. Half of DBL_MIN is two to the power minus one thousand twenty-three and remains subnormal. DBL_MIN is two to the power minus one thousand twenty-two and is the smallest positive normal binary64 double. Halving the smallest positive subnormal rounds to zero under round-to-nearest. The picture shows value categories, not proportional distances.

The experiment requires binary64, gradual subnormals, and round-to-nearest. Boxes are not to scale; the C classification functions determine the printed results.

### main.c

```c
#include <stdio.h>
#include <stdbool.h>
#include <limits.h>
#include <stdint.h>
#include <stddef.h>
#include <math.h>
#include <float.h>
#include <fenv.h>
_Static_assert(FLT_RADIX==2&&DBL_MANT_DIG==53&&DBL_MAX_EXP==1024,
               "This native demonstration requires binary64 double");
#include <errno.h>


int main(void) {
    _Static_assert(DBL_HAS_SUBNORM==1,"This fixture requires gradual subnormals");
    int previous=fegetround();if(previous<0||fesetround(FE_TONEAREST)!=0)return 1;
    double below_normal=scalbn(DBL_MIN,-1);
    double smallest=nextafter(0.0,1.0);errno=0;
    volatile double source=smallest;double lost=scalbn(source,-1);
    printf("below_min_is_subnormal=%d smallest_positive=%d\n",fpclassify(below_normal)==FP_SUBNORMAL,smallest>0.0);
    printf("scaled_to_zero=%d finite_subnormal=%d\n",lost==0.0,isfinite(below_normal)!=0);
    if(fesetround(previous)!=0)return 1;
    return 0;
}
```

Output:

```text
below_min_is_subnormal=1 smallest_positive=1
scaled_to_zero=1 finite_subnormal=1
```

Half of DBL_MIN remains a finite subnormal on these targets. Halving the smallest subnormal through scalbn rounds to zero under the chosen rounding mode. The value does not wrap to a large positive number. This example intentionally checks portable classification interfaces under a stated floating-format contract instead of asserting one exact errno or exception-flag result.

**Watch for:** A finite check alone does not detect every underflow because a tiny result may be a finite subnormal or zero. Decide whether tiny values are acceptable; rejecting every ERANGE in a parser is one strict policy, not the only valid numerical policy.

**Check:** What does DBL_MIN describe?

1. The most negative finite double
2. The smallest positive normal double

<details><summary>Answer</summary>

The smallest positive normal double. Use -DBL_MAX for the negative finite endpoint; subnormal values may exist between zero and DBL_MIN.

</details>

**Try:** Edit the example in Browser Linux.  In native/examples/c-guarantees-10/main.c, change double lost=scalbn(source,-1); to double lost=scalbn(source,0);. Repeat the terminal run. Compare scaled_to_zero= and finite_subnormal=. Which classifications depend on applying another halving?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: floating-point limits (included in the explanation above) — Find precision, exponent-range, and subnormal-support macros.
- [Read sqrt(3)](../../manuals/sqrt.3.txt) (included) — sqrt, sqrtf, sqrtl - square root function

**Optional further reading (internet required):**

- [C reference: floating-point limits](https://en.cppreference.com/w/c/types/limits.html)
- [C reference: mathematical functions](https://en.cppreference.com/w/c/numeric/math.html)

Native source: `native/examples/c-guarantees-10/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=c-guarantees-10 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## Chapter practice

Edit `native/exercises/arithmetic.c`, then run:

```sh
make exercise EXERCISE=arithmetic
```

## Build it yourself

Audit numeric assumptions and implement a checked arithmetic interface with boundary and rejection tests.

1. Implement the checked-arithmetic exercise and preserve the output object after rejection.
2. Test endpoints, all operand signs, zero divisors, the exceptional quotient, and narrowing limits.
3. Run the floating-point probes in Browser Linux and document target, rounding mode, finite-value policy, and tolerance assumptions.

### Check your work

- Compare integer results against an independent arbitrary-precision oracle before accepting a boundary result.
- Verify that rejected operations never evaluate invalid arithmetic and do not change caller output.
- Check finite values, NaN/infinity rejection, and subnormal/zero classification under the stated floating target contract.

Baseline command (checks original output, not every extension):

```sh
make example EXAMPLE=c-guarantees-10
```

Chapter workspace command: `make chapter CHAPTER=c-guarantees`.

Generated from dist/part7.js by tools/sync_readings.cjs. Full reading: https://snowch.github.io/c-foundry/#/chapter/c-guarantees
