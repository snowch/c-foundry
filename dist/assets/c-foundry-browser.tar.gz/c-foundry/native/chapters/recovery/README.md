# Chapter 29: Transactions and recovery

Part 6: Make the database faster and more reliable. Teaching baseline: C17.

Separate transaction visibility from durable acknowledgement. Model interrupted log prefixes and preserve committed state.

## Outcomes

- Apply transaction changes atomically to a single-writer in-memory state.
- Explain write-ahead ordering and durable commit records.
- Replay committed records while ignoring an incomplete tail.

## 29.1 Atomicity, consistency, isolation, and durability

Atomicity, consistency, isolation, and durability describe different obligations. Name which ones an implementation actually provides.

Also editable and runnable inline in the browser course.

The copy-on-begin transaction model keeps uncommitted changes in a private working table, providing an all-or-nothing publication step for this single-threaded fixture. Table operations enforce schema consistency. It provides neither concurrent isolation nor crash durability by itself; those need synchronization and a persistence protocol. A process-local struct assignment is not a durable commit.

### A private working copy can commit or roll back

Illustrative transaction: live score 10 is separate from tentative score 42.

The live table starts with a score of 10. Begin copies it into a private working table. Editing changes the working score to 42 while live remains 10. Commit publishes the working table, making live 42. Rollback discards the working changes and leaves live 10.

An in-process, single-writer model. Publication alone provides neither crash durability nor concurrent isolation.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { TABLE_CAP = 8 };
typedef struct {
  uint32_t id;
  char name[32];
  uint32_t score;
} Row;
typedef struct {
  Row rows[TABLE_CAP];
  size_t count;
} Table;
typedef enum { OK, DUPLICATE, FULL, INVALID, MISSING } Status;
int find_row(const Table *t, uint32_t id) {
  for (size_t i = 0; i < t->count; ++i)
    if (t->rows[i].id == id)
      return (int)i;
  return -1;
}
Status insert_row(Table *t, Row row) {
  if (row.id == 0 || !memchr(row.name, 0, sizeof row.name) || row.name[0] == 0)
    return INVALID;
  if (find_row(t, row.id) >= 0)
    return DUPLICATE;
  if (t->count == TABLE_CAP)
    return FULL;
  t->rows[t->count++] = row;
  return OK;
}
Status update_score(Table *t, uint32_t id, uint32_t score) {
  int i = find_row(t, id);
  if (i < 0)
    return MISSING;
  t->rows[i].score = score;
  return OK;
}
Status delete_row(Table *t, uint32_t id) {
  int i = find_row(t, id);
  if (i < 0)
    return MISSING;
  for (size_t j = (size_t)i + 1; j < t->count; ++j)
    t->rows[j - 1] = t->rows[j];
  --t->count;
  return OK;
}
void display(const Table *t) {
  for (size_t i = 0; i < t->count; ++i)
    printf("%u | %s | %u\n", (unsigned)t->rows[i].id, t->rows[i].name,
           (unsigned)t->rows[i].score);
}
typedef struct {
  Table working;
  Table *live;
  bool active;
} Transaction;
bool begin(Transaction *tx, Table *live) {
  if (tx->active)
    return false;
  tx->working = *live;
  tx->live = live;
  tx->active = true;
  return true;
}
bool commit(Transaction *tx) {
  if (!tx->active)
    return false;
  *tx->live = tx->working;
  tx->active = false;
  return true;
}
void rollback(Transaction *tx) {
  tx->active = false;
  tx->live = NULL;
}

int main(void) {
  Table live = {.count = 0};
  insert_row(&live, (Row){1, "Ada", 90});
  Transaction tx = {.active = false};
  begin(&tx, &live);
  update_score(&tx.working, 1, 1);
  rollback(&tx);
  printf("after_rollback=%u\n", (unsigned)live.rows[0].score);
  return 0;
}
```

Output:

```text
after_rollback=90
```

The tentative score one was never copied into live state. Rollback discards the transaction’s publication ability.

**Watch for:** Passing a rollback test does not establish the other ACID properties.

**Check:** Does this memory-only rollback guarantee durability?

1. No
2. Yes

<details><summary>Answer</summary>

No. Process memory can disappear without a persistent recovery protocol.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/recovery/1). In main.c, change the tentative score from 1 to 50, leaving rollback(&tx) unchanged. Run code and compare after_rollback=. Which state did update_score edit, and which state does the printed value come from?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: atomic commit (included in the explanation above) — Read the failure assumptions and ordering required for a durable commit protocol.
- Course notes: write-ahead logging (included in the explanation above) — Compare logging, checkpoints, and durability assumptions with the bounded redo models.

**Optional further reading (internet required):**

- [SQLite documentation: atomic commit](https://www.sqlite.org/atomiccommit.html)
- [SQLite documentation: write-ahead logging](https://www.sqlite.org/wal.html)

Native source: `native/examples/recovery-1/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=recovery-1 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 29.2 A single-writer transaction model

A single-writer transaction model serializes mutations and simplifies conflict handling. The restriction must be enforced by the caller or service.

Also editable and runnable inline in the browser course.

begin refuses to start another transaction using the same active handle, but the model has no global lock. A real multi-client service must route all writers through one owner or protect admission with synchronization. Readers also need a contract about whether they see committed state or a working copy.

### A private working copy can commit or roll back

Illustrative transaction: live score 10 is separate from tentative score 42.

The live table starts with a score of 10. Begin copies it into a private working table. Editing changes the working score to 42 while live remains 10. Commit publishes the working table, making live 42. Rollback discards the working changes and leaves live 10.

An in-process, single-writer model. Publication alone provides neither crash durability nor concurrent isolation.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { TABLE_CAP = 8 };
typedef struct {
  uint32_t id;
  char name[32];
  uint32_t score;
} Row;
typedef struct {
  Row rows[TABLE_CAP];
  size_t count;
} Table;
typedef enum { OK, DUPLICATE, FULL, INVALID, MISSING } Status;
int find_row(const Table *t, uint32_t id) {
  for (size_t i = 0; i < t->count; ++i)
    if (t->rows[i].id == id)
      return (int)i;
  return -1;
}
Status insert_row(Table *t, Row row) {
  if (row.id == 0 || !memchr(row.name, 0, sizeof row.name) || row.name[0] == 0)
    return INVALID;
  if (find_row(t, row.id) >= 0)
    return DUPLICATE;
  if (t->count == TABLE_CAP)
    return FULL;
  t->rows[t->count++] = row;
  return OK;
}
Status update_score(Table *t, uint32_t id, uint32_t score) {
  int i = find_row(t, id);
  if (i < 0)
    return MISSING;
  t->rows[i].score = score;
  return OK;
}
Status delete_row(Table *t, uint32_t id) {
  int i = find_row(t, id);
  if (i < 0)
    return MISSING;
  for (size_t j = (size_t)i + 1; j < t->count; ++j)
    t->rows[j - 1] = t->rows[j];
  --t->count;
  return OK;
}
void display(const Table *t) {
  for (size_t i = 0; i < t->count; ++i)
    printf("%u | %s | %u\n", (unsigned)t->rows[i].id, t->rows[i].name,
           (unsigned)t->rows[i].score);
}
typedef struct {
  Table working;
  Table *live;
  bool active;
} Transaction;
bool begin(Transaction *tx, Table *live) {
  if (tx->active)
    return false;
  tx->working = *live;
  tx->live = live;
  tx->active = true;
  return true;
}
bool commit(Transaction *tx) {
  if (!tx->active)
    return false;
  *tx->live = tx->working;
  tx->active = false;
  return true;
}
void rollback(Transaction *tx) {
  tx->active = false;
  tx->live = NULL;
}

int main(void) {
  Table live = {.count = 0};
  Transaction tx = {.active = false};
  bool first = begin(&tx, &live), nested = begin(&tx, &live);
  printf("first=%d nested=%d live_rows=%zu\n", first, nested, live.count);
  rollback(&tx);
  return 0;
}
```

Output:

```text
first=1 nested=0 live_rows=0
```

The active flag protects one handle’s lifecycle. It does not prevent a second unrelated handle from writing the same live table.

**Watch for:** A comment saying single writer does not synchronize multiple clients.

**Check:** What must the surrounding service enforce?

1. Only a per-thread local variable name
2. Exclusive mutation ownership

<details><summary>Answer</summary>

Exclusive mutation ownership. The same live state must not be concurrently mutated through independent handles.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/recovery/2). In main.c, replace the declarations of first and nested with separate calls, inserting rollback(&tx) between them. Run code and compare first= and nested=. Why can the second begin succeed once the model has no active transaction?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: transactions (included in the explanation above) — Compare BEGIN, COMMIT, and ROLLBACK with the deliberately smaller transaction model.
- Course notes: atomic commit (included in the explanation above) — Read the failure assumptions and ordering required for a durable commit protocol.

**Optional further reading (internet required):**

- [SQLite documentation: transactions](https://www.sqlite.org/lang_transaction.html)
- [SQLite documentation: atomic commit](https://www.sqlite.org/atomiccommit.html)

Native source: `native/examples/recovery-2/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=recovery-2 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 29.3 BEGIN, COMMIT, and ROLLBACK

BEGIN establishes a working state, COMMIT publishes it under the model’s contract, and ROLLBACK discards it. Repeated or out-of-order commands need defined failures.

Also editable and runnable inline in the browser course.

The fixture commits one score update and then rolls back another. In this bounded single-threaded model, readers of live state see only the committed value. A production commit must also handle log failures and durable acknowledgement; copying the table here teaches state transition semantics only.

### A private working copy can commit or roll back

Illustrative transaction: live score 10 is separate from tentative score 42.

The live table starts with a score of 10. Begin copies it into a private working table. Editing changes the working score to 42 while live remains 10. Commit publishes the working table, making live 42. Rollback discards the working changes and leaves live 10.

An in-process, single-writer model. Publication alone provides neither crash durability nor concurrent isolation.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { TABLE_CAP = 8 };
typedef struct {
  uint32_t id;
  char name[32];
  uint32_t score;
} Row;
typedef struct {
  Row rows[TABLE_CAP];
  size_t count;
} Table;
typedef enum { OK, DUPLICATE, FULL, INVALID, MISSING } Status;
int find_row(const Table *t, uint32_t id) {
  for (size_t i = 0; i < t->count; ++i)
    if (t->rows[i].id == id)
      return (int)i;
  return -1;
}
Status insert_row(Table *t, Row row) {
  if (row.id == 0 || !memchr(row.name, 0, sizeof row.name) || row.name[0] == 0)
    return INVALID;
  if (find_row(t, row.id) >= 0)
    return DUPLICATE;
  if (t->count == TABLE_CAP)
    return FULL;
  t->rows[t->count++] = row;
  return OK;
}
Status update_score(Table *t, uint32_t id, uint32_t score) {
  int i = find_row(t, id);
  if (i < 0)
    return MISSING;
  t->rows[i].score = score;
  return OK;
}
Status delete_row(Table *t, uint32_t id) {
  int i = find_row(t, id);
  if (i < 0)
    return MISSING;
  for (size_t j = (size_t)i + 1; j < t->count; ++j)
    t->rows[j - 1] = t->rows[j];
  --t->count;
  return OK;
}
void display(const Table *t) {
  for (size_t i = 0; i < t->count; ++i)
    printf("%u | %s | %u\n", (unsigned)t->rows[i].id, t->rows[i].name,
           (unsigned)t->rows[i].score);
}
typedef struct {
  Table working;
  Table *live;
  bool active;
} Transaction;
bool begin(Transaction *tx, Table *live) {
  if (tx->active)
    return false;
  tx->working = *live;
  tx->live = live;
  tx->active = true;
  return true;
}
bool commit(Transaction *tx) {
  if (!tx->active)
    return false;
  *tx->live = tx->working;
  tx->active = false;
  return true;
}
void rollback(Transaction *tx) {
  tx->active = false;
  tx->live = NULL;
}

int main(void) {
  Table live = {.count = 0};
  insert_row(&live, (Row){1, "Ada", 90});
  Transaction tx = {.active = false};
  begin(&tx, &live);
  update_score(&tx.working, 1, 95);
  commit(&tx);
  begin(&tx, &live);
  update_score(&tx.working, 1, 0);
  rollback(&tx);
  printf("committed_score=%u invalid_commit=%d\n", (unsigned)live.rows[0].score,
         !commit(&tx));
  return 0;
}
```

Output:

```text
committed_score=95 invalid_commit=1
```

The committed 95 survives the later rollback. Committing an inactive transaction fails.

**Watch for:** A failed durable commit must not be reported as successful merely because the working copy is valid.

**Check:** In the original program, a score of 95 is committed and a later tentative zero is rolled back. Which score remains live?

1. The earlier committed 95
2. The later tentative zero

<details><summary>Answer</summary>

The earlier committed 95. Rollback never publishes its private working table.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/recovery/3). In main.c, change the first transaction’s score from 95 to 50 and leave the second rollback in place. Run code and compare committed_score= and invalid_commit=. Which boundary made 50 observable in live?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: transactions (included in the explanation above) — Compare BEGIN, COMMIT, and ROLLBACK with the deliberately smaller transaction model.
- Course notes: atomic commit (included in the explanation above) — Read the failure assumptions and ordering required for a durable commit protocol.

**Optional further reading (internet required):**

- [SQLite documentation: transactions](https://www.sqlite.org/lang_transaction.html)
- [SQLite documentation: atomic commit](https://www.sqlite.org/atomiccommit.html)

Native source: `native/examples/recovery-3/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=recovery-3 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 29.4 Write-ahead logging

Write-ahead logging records enough information for recovery before acknowledging a durable commit or persisting dependent data pages.

The one-value redo log uses eight-byte BEGIN, SET, and COMMIT records with transaction IDs. In this POSIX fixture, the program checks the write, flushes the library buffer, calls fsync on the temporary file and then runs recovery over the same prepared bytes. A database also needs a recovery-visible log path, error handling and an ordering contract for log and data files.

### Recovery keeps committed work and ignores an incomplete tail

Illustrative log: commit value 42, then leave value 99 uncommitted.

Read a log containing BEGIN, SET score to 42, COMMIT, then a second BEGIN and SET score to 99 with no complete matching COMMIT. Recovery applies the first transaction. It ignores the incomplete second transaction, so the recovered score is 42. A short or invalid tail must be handled according to the log format.

These are logical records, not their byte encoding. Checksums and host write ordering require separate mechanisms.

### main.c

```c
#define _POSIX_C_SOURCE 200809L
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

enum { ROW_BYTES = 40, HEADER_BYTES = 8, PAGE_BYTES = 128 };
void put32(unsigned char *out, uint32_t value) {
  for (unsigned i = 0; i < 4; ++i)
    out[i] = (unsigned char)(value >> (8 * i));
}
uint32_t get32(const unsigned char *in) {
  uint32_t value = 0;
  for (unsigned i = 0; i < 4; ++i)
    value |= (uint32_t)in[i] << (8 * i);
  return value;
}
enum { BEGIN_REC = 1, SET_REC = 2, COMMIT_REC = 3, LOG_BYTES = 8 };
void log_record(unsigned char *out, unsigned kind, unsigned tx,
                uint32_t value) {
  memset(out, 0, LOG_BYTES);
  out[0] = (unsigned char)kind;
  out[1] = (unsigned char)tx;
  put32(out + 4, value);
}
uint32_t recover(const unsigned char *log, size_t length, uint32_t base) {
  unsigned active = 0;
  uint32_t pending = base;
  for (size_t at = 0; at <= length && length - at >= LOG_BYTES;
       at += LOG_BYTES) {
    const unsigned char *r = log + at;
    if (!r[1] || r[2] || r[3])
      break;
    if (r[0] == BEGIN_REC) {
      if (active)
        break;
      active = r[1];
      pending = base;
    } else if (r[0] == SET_REC) {
      if (active != r[1])
        break;
      pending = get32(r + 4);
    } else if (r[0] == COMMIT_REC) {
      if (active != r[1])
        break;
      base = pending;
      active = 0;
    } else
      break;
  }
  return base;
}

int main(void) {
  FILE *f = tmpfile();
  if (!f)
    return 1;
  unsigned char bytes[24];
  log_record(bytes, BEGIN_REC, 1, 0);
  log_record(bytes + 8, SET_REC, 1, 42);
  log_record(bytes + 16, COMMIT_REC, 1, 0);
  bool ok = fwrite(bytes, 1, sizeof bytes, f) == sizeof bytes &&
            fflush(f) == 0 && fsync(fileno(f)) == 0;
  if (!ok) {
    fclose(f);
    return 1;
  }
  printf("sync_calls_succeeded value=%u\n",
         (unsigned)recover(bytes, sizeof bytes, 0));
  if (fclose(f) != 0)
    return 1;
  return 0;
}
```

Output:

```text
sync_calls_succeeded value=42
```

The prepared log decodes to 42. The success line follows the checked sync call. The fixture uses a temporary file and runs no crash or power-loss test.

**Watch for:** fflush alone moves bytes to the operating-system interface; it is not equivalent to a platform durable-sync operation.

**Check:** When may a durable commit be acknowledged under this protocol?

1. Immediately after writing a private memory copy
2. After its required log synchronization succeeds

<details><summary>Answer</summary>

After its required log synchronization succeeds. Recovery must be able to find a durable commit record before success is promised.

</details>

**Try:** Edit the example in Browser Linux.  In native/examples/recovery-4/main.c, change the value argument of the SET_REC log_record call from 42 to 17. Repeat the terminal command. Find sync_calls_succeeded and value=17. Which code checks the write, flush, and sync before the recovery result is printed?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: atomic commit (included in the explanation above) — Read the failure assumptions and ordering required for a durable commit protocol.
- Course notes: write-ahead logging (included in the explanation above) — Compare logging, checkpoints, and durability assumptions with the bounded redo models.
- [Read fsync(2)](../../manuals/fsync.2.txt) (included) — Compare an OS synchronization request with C stream flushing; read filesystem-specific limitations.

**Optional further reading (internet required):**

- [SQLite documentation: atomic commit](https://www.sqlite.org/atomiccommit.html)
- [SQLite documentation: write-ahead logging](https://www.sqlite.org/wal.html)

**Use the documentation (optional):** Does a successful fflush alone establish that a committed record survives power loss?

<details><summary>Compare your answer</summary>

No. fflush addresses C stream buffering. Durable commit needs a host/storage protocol and explicit failure assumptions; read how the reference separates these layers.

</details>

Native source: `native/examples/recovery-4/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=recovery-4 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 29.5 Recovery after an interrupted write

Recovery should apply committed transactions and ignore an incomplete final transaction. Test every interruption boundary rather than only whole-record cuts.

Also editable and runnable inline in the browser course.

The bounded redo model scans complete eight-byte records, retains tentative state until a matching COMMIT, and stops at invalid structure. A short tail is ignored. SET stores the final value rather than an increment, making replay idempotent for the same log and base. This format has no checksum, so it cannot reliably detect every bit flip that still forms a valid record.

### Recovery keeps committed work and ignores an incomplete tail

Illustrative log: commit value 42, then leave value 99 uncommitted.

Read a log containing BEGIN, SET score to 42, COMMIT, then a second BEGIN and SET score to 99 with no complete matching COMMIT. Recovery applies the first transaction. It ignores the incomplete second transaction, so the recovered score is 42. A short or invalid tail must be handled according to the log format.

These are logical records, not their byte encoding. Checksums and host write ordering require separate mechanisms.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { ROW_BYTES = 40, HEADER_BYTES = 8, PAGE_BYTES = 128 };
void put32(unsigned char *out, uint32_t value) {
  for (unsigned i = 0; i < 4; ++i)
    out[i] = (unsigned char)(value >> (8 * i));
}
uint32_t get32(const unsigned char *in) {
  uint32_t value = 0;
  for (unsigned i = 0; i < 4; ++i)
    value |= (uint32_t)in[i] << (8 * i);
  return value;
}
enum { BEGIN_REC = 1, SET_REC = 2, COMMIT_REC = 3, LOG_BYTES = 8 };
void log_record(unsigned char *out, unsigned kind, unsigned tx,
                uint32_t value) {
  memset(out, 0, LOG_BYTES);
  out[0] = (unsigned char)kind;
  out[1] = (unsigned char)tx;
  put32(out + 4, value);
}
uint32_t recover(const unsigned char *log, size_t length, uint32_t base) {
  unsigned active = 0;
  uint32_t pending = base;
  for (size_t at = 0; at <= length && length - at >= LOG_BYTES;
       at += LOG_BYTES) {
    const unsigned char *r = log + at;
    if (!r[1] || r[2] || r[3])
      break;
    if (r[0] == BEGIN_REC) {
      if (active)
        break;
      active = r[1];
      pending = base;
    } else if (r[0] == SET_REC) {
      if (active != r[1])
        break;
      pending = get32(r + 4);
    } else if (r[0] == COMMIT_REC) {
      if (active != r[1])
        break;
      base = pending;
      active = 0;
    } else
      break;
  }
  return base;
}

int main(void) {
  unsigned char log[40];
  log_record(log, BEGIN_REC, 1, 0);
  log_record(log + 8, SET_REC, 1, 10);
  log_record(log + 16, COMMIT_REC, 1, 0);
  log_record(log + 24, BEGIN_REC, 2, 0);
  log_record(log + 32, SET_REC, 2, 99);
  printf("committed=%u torn=%u\n", (unsigned)recover(log, sizeof log, 0),
         (unsigned)recover(log, 19, 0));
  return 0;
}
```

Output:

```text
committed=10 torn=0
```

The complete first transaction publishes ten. The later uncommitted 99 is ignored. Cutting the first COMMIT record at byte nineteen leaves no committed change.

**Watch for:** Ignoring a torn tail is not a general policy for silently skipping corruption in the middle of a log.

**Check:** In the redo-log model, is a SET record alone enough to publish a transaction?

1. No, a valid matching COMMIT is required
2. Yes

<details><summary>Answer</summary>

No, a valid matching COMMIT is required. Tentative state remains separate until the commit boundary.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/recovery/5). In main.c, change recover(log, 19, 0) to recover(log, 24, 0) and rename torn= to prefix24=. Run code and compare both values. Which complete record at byte 24 makes the first transaction eligible for replay?

**Extend the example:** Copy the prepared log into a separate fixture with a second commit and a third torn transaction. Record expected visible values independently before testing the byte prefixes.

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: atomic commit (included in the explanation above) — Read the failure assumptions and ordering required for a durable commit protocol.
- Course notes: write-ahead logging (included in the explanation above) — Compare logging, checkpoints, and durability assumptions with the bounded redo models.

**Optional further reading (internet required):**

- [SQLite documentation: atomic commit](https://www.sqlite.org/atomiccommit.html)
- [SQLite documentation: write-ahead logging](https://www.sqlite.org/wal.html)

Native source: `native/examples/recovery-5/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=recovery-5 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## 29.6 Browser storage guarantees and their limits

Browser persistence APIs have their own atomicity and completion contracts. A native filesystem protocol cannot simply be assumed to transfer to browser storage.

Also editable and runnable inline in the browser course.

The executable model illustrates a complete versus interrupted commit boundary. In a browser host, IndexedDB transactions or OPFS operations need an explicit integration layer, quota/error handling, and documented acknowledgement rules. localStorage lesson marks and downloadable files are useful product features but are not a write-ahead-log durability mechanism for the C program. Inline lesson runs keep program files temporary. The command workspace saves files between successful runs through its browser storage layer; that file transfer does not implement a C write-ahead log or prove recovery after power loss.

### main.c

```c
#include <limits.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { ROW_BYTES = 40, HEADER_BYTES = 8, PAGE_BYTES = 128 };
void put32(unsigned char *out, uint32_t value) {
  for (unsigned i = 0; i < 4; ++i)
    out[i] = (unsigned char)(value >> (8 * i));
}
uint32_t get32(const unsigned char *in) {
  uint32_t value = 0;
  for (unsigned i = 0; i < 4; ++i)
    value |= (uint32_t)in[i] << (8 * i);
  return value;
}
enum { BEGIN_REC = 1, SET_REC = 2, COMMIT_REC = 3, LOG_BYTES = 8 };
void log_record(unsigned char *out, unsigned kind, unsigned tx,
                uint32_t value) {
  memset(out, 0, LOG_BYTES);
  out[0] = (unsigned char)kind;
  out[1] = (unsigned char)tx;
  put32(out + 4, value);
}
uint32_t recover(const unsigned char *log, size_t length, uint32_t base) {
  unsigned active = 0;
  uint32_t pending = base;
  for (size_t at = 0; at <= length && length - at >= LOG_BYTES;
       at += LOG_BYTES) {
    const unsigned char *r = log + at;
    if (!r[1] || r[2] || r[3])
      break;
    if (r[0] == BEGIN_REC) {
      if (active)
        break;
      active = r[1];
      pending = base;
    } else if (r[0] == SET_REC) {
      if (active != r[1])
        break;
      pending = get32(r + 4);
    } else if (r[0] == COMMIT_REC) {
      if (active != r[1])
        break;
      base = pending;
      active = 0;
    } else
      break;
  }
  return base;
}

int main(void) {
  unsigned char log[24];
  log_record(log, BEGIN_REC, 1, 0);
  log_record(log + 8, SET_REC, 1, 7);
  log_record(log + 16, COMMIT_REC, 1, 0);
  printf("before_commit=%u after_commit=%u\n", (unsigned)recover(log, 16, 0),
         (unsigned)recover(log, 24, 0));
  return 0;
}
```

Output:

```text
before_commit=0 after_commit=7
```

The boundary model is portable C, but the host mechanism that persists and acknowledges those bytes is environment-specific.

**Watch for:** Do not label a successful browser download or a saved editor draft as an atomic database transaction.

**Check:** Does localStorage progress persistence make the C filesystem durable?

1. Yes
2. No

<details><summary>Answer</summary>

No. The two stores have different owners, data, and failure contracts.

</details>

**Try:** [Try this edit in the browser](https://snowch.github.io/c-foundry/#/chapter/recovery/6). In main.c, change the value 7 in the SET_REC call to 12. Run code and compare before_commit= and after_commit=. This replays a prepared log in memory. Which prefix contains the record that publishes the change?

### References and help

Offline C manuals: run `python3 tools/man.py 3 printf` at the repository root, or use [the bundled manual reader](https://snowch.github.io/c-foundry/#/manual). Browser Linux also provides `man 3 printf` and `man -k keyword`.

- Course notes: atomic commit (included in the explanation above) — Read the failure assumptions and ordering required for a durable commit protocol.
- Course notes: WebAssembly concepts (included in the explanation above) — Distinguish source code, a Wasm module, and the host/runtime that supplies its environment.

**Optional further reading (internet required):**

- [SQLite documentation: atomic commit](https://www.sqlite.org/atomiccommit.html)
- [WebAssembly concepts](https://developer.mozilla.org/en-US/docs/WebAssembly/Guides/Concepts)

Native source: `native/examples/recovery-6/`. The command below builds that source and prints its output in the terminal. Run from the repository root:

```sh
make example EXAMPLE=recovery-6 RUN_ONLY=1
```

Remove RUN_ONLY=1 to compare the starter with its original output.

## Build it yourself

Recover committed changes after simulated interruptions.

1. Specify a browser host persistence adapter and list its transaction, quota, crash, and export guarantees before implementing it.
2. List expected values for all 25 prefixes of the 24-byte log, then add a second committed transaction and a torn third one.

### Check your work

- Check only complete matching commits change the recovered value. Keep browser-host persistence design separate from this in-memory replay test.

Baseline command (checks original output, not every extension):

```sh
make example EXAMPLE=recovery-6
```

Chapter workspace command: `make chapter CHAPTER=recovery`.

Generated from dist/part6.js by tools/sync_readings.cjs. Full reading: https://snowch.github.io/c-foundry/#/chapter/recovery
