# C Foundry offline/update adapter

The [shared offline/update design](https://github.com/snowch/cuda-cpp-lab/blob/main/docs/offline-update-design.md) defines the mechanism. C Foundry uses the same release validator, service worker, status UI and persistent runtime recovery, with a separate `c-foundry:` scope and cache prefix.

## What is saved

App status can save all course readings, original diagrams, example sources, local fonts/icons, the course source archive, the bundled TinyDB program and the inline C compiler. Inline examples and the C command workspace can then compile and run in a fresh offline tab. The complete saved course also includes the self-hosted v86 terminal, firmware, Linux kernel and guest chunks. Browser Linux must boot and run an unvisited example in a fresh offline tab before readiness is accepted. Only optional external documentation and separately installed desktop tools require internet access.

Automatic checks fetch small release metadata, not the full compiler. Online navigation remains fresh. One primary action reflects the saved copy: Save offline copy, Update offline copy or Repair offline copy. Completed downloads are ready only after all manifest files pass byte verification. A downloaded update offers Restart to update. Interrupted/cancelled downloads retain completed files and keep an earlier complete copy usable. Request persistent browser storage when supported; device/browser eviction remains possible.

`tools/build.mjs` copies authored `dist/` to `.build/site` and generates a SHA-256 manifest and immutable release tree. `dist/` is tracked source and must not be deleted as generated output. HTML pins scripts, styles, the homepage illustration and local downloads. Worker dependencies and runtime data resolve inside that release. Publication retains two preceding immutable releases and verifies exact original bytes. The first adoption retains the original unversioned worker URLs and compatible message formats, so an older open tab can still run after deployment; the checked-in compiler binaries remain unchanged.

## Learner stores and restart

Existing stores remain unchanged: `c-foundry-v1` for lesson drafts/inputs/practice state, `c-foundry:lesson-done:v1:` for explicit reading marks, IndexedDB `c-foundry-workspace` for revision-checked workspace files, and `c-foundry-linux-source:` for Linux source-editor drafts. Results and optional predictions extend the existing lesson state. Per-field merges preserve independent drafts from another tab. Same-file simultaneous edits retain the existing last-writer behaviour.

`reading-state.js` adapts PREPARE_RESTART → COMMIT_RESTART / ABORT_RESTART. Every controlled tab must save successfully. Per-tab snapshots retain the hash, open disclosures, controls, output, selected source file and workspace transcript/session. Reload never automatically runs code. Failed storage, composition, a running program, unsaved/conflicting workspace files, unsaved Linux source drafts or an active Linux VM veto restart. The VM must be backed up and stopped explicitly; the course never claims to save its guest filesystem.

## Error recovery

Missing, failed or incompatible runtime downloads are infrastructure failures. Keep the previous genuine result and show the persistent native recovery modal with a dimmed background, Reload lesson and Stay on lesson. Escape stays; focus returns to the initiating control. Save first, cancel navigation if saving fails, and retain the inline recovery action. Reload needs an online connection and requires an explicit Run afterward. Ordinary C diagnostics remain beside the editor; practice output comparisons and understanding feedback are separate.

## Verification

Exercise first reading without a compiler download; manual/implicit startup and Escape; warm inline/multi-file/workspace use; stop and idle release; a complete save followed by a fresh offline tab and real compilation; old-tab first Run after deployment; two-tab update/restart; failed-save veto; preservation of independent drafts, prediction, output and marks; workspace conflicts; active-Linux/unsaved-file guards; return online and offline-copy removal. Check phone/desktop, both themes, focus and inline resource rows. Functional checks do not establish learning effectiveness.

## Reconnecting and reopening status

Opening App status forces a small metadata check and local-copy verification immediately and after that check settles. Returning online also refreshes the saved-copy state after checking the host. A failed or aborted check while offline must not leave an earlier ready message visible after cache files have changed. Complete-copy verification can share an in-flight scan across tabs; corruption tests wait for that scan to finish and then require a fresh scan.

A manual status check sends `STATUS` with `fresh: true`. The worker waits for scans already in progress, forwarding their progress so the request does not time out, then checks the cache again. This prevents a scan that read an early file before eviction from supplying the result of a later manual check. Concurrent checks that begin after the request may still share work. Corruption/reconnect tests use the actual status control and return the tab to the foreground.

While a fresh local check is pending, the dialog says “Checking saved copy” instead of repeating an earlier ready message. A failed verification request invalidates the displayed readiness until a later check succeeds; it does not remove the learner’s saved files or drafts.

An older installed worker may ignore the new `fresh` field. Workers supporting the boundary advertise `freshVerification: 1`; otherwise the page waits for the first STATUS reply and requests STATUS again before displaying readiness. This supplies a fresh check without forcing a waiting worker to activate over open learner windows.

## Embedded Linux document URLs

`linux/index.html` is an embedded runtime component, not a second course shell.
Keep its dependency URLs relative and do not inject App status or rewrite its
links as if it lived at the course root. The parent script resolves its iframe
against the script's immutable release directory; the frame's relative imports
then remain inside that same release. All of those files are still hashed and
saved by the parent's complete manifest. An active guest vetoes restart until the
learner exports and stops it. Test the actual course iframe, not only a standalone
runtime page: a double release prefix can leave isolated runtime tests passing
while the course cannot start the guest.

## Stalled native background downloads

Background Fetch is an optional transport, not proof that a download will finish. Chromium CI stalled at the same byte count after both three and six minutes. When a visible, online page observes 45 seconds without byte progress, it asks the worker to hand the existing job to foreground fetch. The worker records `foregroundOnly` before aborting the native registration so an abort event cannot revoke the learner's consent or start the same transport again. Explicit Cancel remains a separate action that revokes consent.

Native completion events and handoff RPCs join one importer per registration. Completed responses must match the requested release path, byte count and SHA-256 hash. Unresolved native response promises have a bounded ten-second wait and are retried through normal foreground fetch; incomplete or invalid aborted responses are never cached as valid. Verified completed files are reused. The same job ID and update mode remain attached to the request, and the earlier complete course stays usable until the full new release verifies and a safe restart commits it.

The visible page resumes using the existing PREPARE protocol. A refresh, return online or return to the foreground reconnects to the persisted request. Do not promise that a browser can download while suspended: native support is best effort, and foreground progress is the fallback. `background-protocol.cjs` exercises verified partial imports, unresolved records, consent, old-release retention and pending updates; `background-handoff.cjs` exercises the visible-page watchdog and real saved-cache/offline navigation with a stalled transport. The real Linux test separately exercises native Background Fetch, full course verification, fresh offline boot and guest-file restoration.
